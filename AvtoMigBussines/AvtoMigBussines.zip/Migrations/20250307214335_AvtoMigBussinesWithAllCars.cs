﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AvtoMigBussines.Migrations
{
    public partial class AvtoMigBussinesWithAllCars : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5ca727a1-be5c-48bf-84b9-3a7c8e9b02ca");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7fde158f-22b2-4831-8f5e-05d8a9f4c5c8");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bf1bde28-1261-44dc-b067-e3d521c8f4aa");

            migrationBuilder.DeleteData(
                table: "PaymentMethods",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "PaymentMethods",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "PaymentMethods",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "TypeOfOrganizations",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "TypeOfOrganizations",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.InsertData(
                table: "Cars",
                columns: new[] { "Id", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 43, false, "DFSK" },
                    { 44, false, "Dodge" },
                    { 45, false, "DongFeng" },
                    { 46, false, "DS" },
                    { 47, false, "Eagle" },
                    { 48, false, "Enovate" },
                    { 49, false, "Evergrande" },
                    { 50, false, "EXEED" },
                    { 51, false, "Fang Chang Bao" },
                    { 52, false, "Farizon" },
                    { 53, false, "FAW" },
                    { 54, false, "Ferrari" },
                    { 55, false, "Fiat" },
                    { 56, false, "Fisker" },
                    { 57, false, "Ford" },
                    { 58, false, "Forthing" },
                    { 59, false, "Foton" },
                    { 60, false, "GAC" },
                    { 61, false, "Geely" },
                    { 62, false, "Genesis" },
                    { 63, false, "GMC" },
                    { 64, false, "Gonow" },
                    { 65, false, "Great Wall" },
                    { 66, false, "Guojin" },
                    { 67, false, "Hafei" },
                    { 68, false, "Haima" },
                    { 69, false, "Hanteng" },
                    { 70, false, "Haval" },
                    { 71, false, "Hawtai" },
                    { 72, false, "HiPhi" },
                    { 73, false, "Honda" },
                    { 74, false, "Hongqi" },
                    { 75, false, "Hozon" },
                    { 76, false, "HuangHai" },
                    { 77, false, "Huansu" },
                    { 78, false, "Huawei" },
                    { 79, false, "Hummer" },
                    { 80, false, "Hyundai" },
                    { 81, false, "iCar" },
                    { 82, false, "IM" },
                    { 83, false, "Ineos" },
                    { 84, false, "Infiniti" }
                });

            migrationBuilder.InsertData(
                table: "Cars",
                columns: new[] { "Id", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 85, false, "Iran Khodro" },
                    { 86, false, "Isuzu" },
                    { 87, false, "JAC" },
                    { 88, false, "Jaecooo" },
                    { 89, false, "Jaguar" },
                    { 90, false, "Jeep" },
                    { 91, false, "Jetour" },
                    { 92, false, "Jetta" },
                    { 93, false, "JinBei" },
                    { 94, false, "JINPENG" },
                    { 95, false, "Jiyue" },
                    { 96, false, "JMC" },
                    { 97, false, "Kaiyi" },
                    { 98, false, "Karry" },
                    { 99, false, "Kia" },
                    { 100, false, "KYC" },
                    { 101, false, "Lamborghini" },
                    { 102, false, "Lancia" },
                    { 103, false, "Land Rover" },
                    { 104, false, "Landwind" },
                    { 105, false, "Leapmotor" },
                    { 106, false, "Leopaard" },
                    { 107, false, "Lexus" },
                    { 108, false, "LI" },
                    { 109, false, "Lifan" },
                    { 110, false, "Lincoln" },
                    { 111, false, "Livan" },
                    { 112, false, "Lotus" },
                    { 113, false, "Lucid" },
                    { 114, false, "Luxeed" },
                    { 115, false, "Luxgen" },
                    { 116, false, "Lynk & Co" },
                    { 117, false, "Mahindra" },
                    { 118, false, "Maple" },
                    { 119, false, "Maserati" },
                    { 120, false, "Maxus" },
                    { 121, false, "Maybach" },
                    { 122, false, "Mazda" },
                    { 123, false, "McLaren" },
                    { 124, false, "Mercedes-Benz" },
                    { 125, false, "Mercedes-Maybach" },
                    { 126, false, "Mercury" }
                });

            migrationBuilder.InsertData(
                table: "Cars",
                columns: new[] { "Id", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 127, false, "Metrocab" },
                    { 128, false, "MG" },
                    { 129, false, "Mini" },
                    { 130, false, "Mitsubishi" },
                    { 131, false, "Nio" },
                    { 132, false, "Nissan" },
                    { 133, false, "Niutrion" },
                    { 134, false, "NL" },
                    { 135, false, "Oldsmobile" },
                    { 136, false, "OMODA" },
                    { 137, false, "Opel" },
                    { 138, false, "Ora" },
                    { 139, false, "Peugeot" },
                    { 140, false, "Plymouth" },
                    { 141, false, "Polar Stone" },
                    { 142, false, "Polestar" },
                    { 143, false, "Pontiac" },
                    { 144, false, "Porsche" },
                    { 145, false, "Proton" },
                    { 146, false, "Puch" },
                    { 147, false, "Radar" },
                    { 148, false, "RAM" },
                    { 149, false, "Ravon" },
                    { 150, false, "Renault" },
                    { 151, false, "Renault Samsung" },
                    { 152, false, "Rivian" },
                    { 153, false, "Roewe" },
                    { 154, false, "Rolls-Royce" },
                    { 155, false, "Rover" },
                    { 156, false, "Rox" },
                    { 157, false, "Saab" },
                    { 158, false, "SIAC" },
                    { 159, false, "Santana" },
                    { 160, false, "Saturn" },
                    { 161, false, "Skoda" },
                    { 162, false, "Smart" },
                    { 163, false, "Soueast" },
                    { 164, false, "Spartan" },
                    { 165, false, "SsangYong" },
                    { 166, false, "Subaru" },
                    { 167, false, "Suzuki" },
                    { 168, false, "SWM" }
                });

            migrationBuilder.InsertData(
                table: "Cars",
                columns: new[] { "Id", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 169, false, "Tank" },
                    { 170, false, "Tesla" },
                    { 171, false, "Toyota" },
                    { 172, false, "Vokswagen" },
                    { 173, false, "Volvo" },
                    { 174, false, "Voyah" },
                    { 175, false, "Xiamo" },
                    { 176, false, "Zeekr" },
                    { 177, false, "ВАЗ (Lada)" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 697, 43, false, "C31" },
                    { 698, 43, false, "C32" },
                    { 699, 43, false, "C35" },
                    { 700, 43, false, "C36" },
                    { 701, 43, false, "C37" },
                    { 702, 43, false, "C56" },
                    { 703, 43, false, "C71" },
                    { 704, 44, false, "Avenger" },
                    { 705, 44, false, "Caliber" },
                    { 706, 44, false, "Caravan" },
                    { 707, 44, false, "Challenger" },
                    { 708, 44, false, "Charger" },
                    { 709, 44, false, "Dakota" },
                    { 710, 44, false, "Dart" },
                    { 711, 44, false, "Daytona" },
                    { 712, 44, false, "Durango" },
                    { 713, 44, false, "Interepid" },
                    { 714, 44, false, "Journey" },
                    { 715, 44, false, "Magnum" },
                    { 716, 44, false, "Monaco" },
                    { 717, 44, false, "Neon" },
                    { 718, 44, false, "Nitro" },
                    { 719, 44, false, "Ram" },
                    { 720, 44, false, "Shadow" },
                    { 721, 44, false, "Spirit" },
                    { 722, 44, false, "Stealth" },
                    { 723, 44, false, "Stratus" },
                    { 724, 44, false, "Viper" },
                    { 725, 45, false, "Nano EX1" },
                    { 726, 45, false, "580" },
                    { 727, 45, false, "A30" },
                    { 728, 45, false, "A60" },
                    { 729, 45, false, "Aeolus Haohan" },
                    { 730, 45, false, "Aeolus Haoji" },
                    { 731, 45, false, "Aeolus L7" },
                    { 732, 45, false, "Aeolus Yixuan" },
                    { 733, 45, false, "AX4" },
                    { 734, 45, false, "AX7" },
                    { 735, 45, false, "E70" },
                    { 736, 45, false, "EC36" },
                    { 737, 45, false, "EM26" },
                    { 738, 45, false, "EQ5032" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 739, 45, false, "EQ6380" },
                    { 740, 45, false, "EX1" },
                    { 741, 45, false, "Fengon 500" },
                    { 742, 45, false, "Fengon E5" },
                    { 743, 45, false, "Forthing T5 EVO" },
                    { 744, 45, false, "Forthing T5L" },
                    { 745, 45, false, "H30 Cross" },
                    { 746, 45, false, "Joyear S50" },
                    { 747, 45, false, "M5EV" },
                    { 748, 45, false, "Mengshi M-Hero 917" },
                    { 749, 45, false, "MPV" },
                    { 750, 45, false, "Nano (Nammi)" },
                    { 751, 45, false, "Oting" },
                    { 752, 45, false, "P16" },
                    { 753, 45, false, "Paladin" },
                    { 754, 45, false, "Rich" },
                    { 755, 45, false, "S30" },
                    { 756, 45, false, "Shine" },
                    { 757, 45, false, "Shine Max" },
                    { 758, 45, false, "Yipai 007" },
                    { 759, 45, false, "Yipai 008" },
                    { 760, 46, false, "7 Crossback" },
                    { 761, 47, false, "Summit" },
                    { 762, 47, false, "Premier" },
                    { 763, 47, false, "Talon" },
                    { 764, 47, false, "Vision" },
                    { 765, 48, false, "ME7" },
                    { 766, 49, false, "Hengchi 5" },
                    { 767, 50, false, "LX" },
                    { 768, 50, false, "RX" },
                    { 769, 50, false, "TXL" },
                    { 770, 50, false, "VX" },
                    { 771, 51, false, "Leopard 5" },
                    { 772, 52, false, "Xingxiang V6" },
                    { 773, 53, false, "1010" },
                    { 774, 53, false, "1021" },
                    { 775, 53, false, "1024" },
                    { 776, 53, false, "6350" },
                    { 777, 53, false, "6371" },
                    { 778, 53, false, "6390" },
                    { 779, 53, false, "Bestune B70" },
                    { 780, 53, false, "Bestune M9" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 781, 53, false, "Bestune T55" },
                    { 782, 53, false, "Bestune T77" },
                    { 783, 53, false, "Bestune T99" },
                    { 784, 53, false, "Besturn B50" },
                    { 785, 53, false, "Besturn B70" },
                    { 786, 53, false, "Besturn NAT" },
                    { 787, 53, false, "Besturn X40" },
                    { 788, 53, false, "Besturn X80" },
                    { 789, 53, false, "D60" },
                    { 790, 53, false, "Jinn" },
                    { 791, 53, false, "Landmark" },
                    { 792, 53, false, "N5" },
                    { 793, 53, false, "Oley" },
                    { 794, 53, false, "S80" },
                    { 795, 53, false, "T80" },
                    { 796, 53, false, "V2" },
                    { 797, 53, false, "V5" },
                    { 798, 53, false, "V80" },
                    { 799, 53, false, "Vita" },
                    { 800, 53, false, "Xenia R7" },
                    { 801, 54, false, "296 GTB" },
                    { 802, 54, false, "348" },
                    { 803, 54, false, "360" },
                    { 804, 54, false, "456" },
                    { 805, 54, false, "458" },
                    { 806, 54, false, "488" },
                    { 807, 54, false, "550" },
                    { 808, 54, false, "575" },
                    { 809, 54, false, "599" },
                    { 810, 54, false, "612" },
                    { 811, 54, false, "812" },
                    { 812, 54, false, "California" },
                    { 813, 54, false, "Enzo" },
                    { 814, 54, false, "F12 berlinetta" },
                    { 815, 54, false, "F355" },
                    { 816, 54, false, "F40" },
                    { 817, 54, false, "F430" },
                    { 818, 54, false, "F8" },
                    { 819, 54, false, "FF" },
                    { 820, 54, false, "GTC4Lusso" },
                    { 821, 54, false, "Mondial" },
                    { 822, 54, false, "Portofino" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 823, 54, false, "Purosangue" },
                    { 824, 54, false, "Roma" },
                    { 825, 54, false, "SF90 Stradale" },
                    { 826, 54, false, "Testarossa" },
                    { 827, 55, false, "500" },
                    { 828, 55, false, "500e" },
                    { 829, 55, false, "500L" },
                    { 830, 55, false, "500X" },
                    { 831, 55, false, "600" },
                    { 832, 55, false, "Albea" },
                    { 833, 55, false, "Barchetta" },
                    { 834, 55, false, "Brava" },
                    { 835, 55, false, "Bravo" },
                    { 836, 55, false, "Cinquecento" },
                    { 837, 55, false, "Coupe" },
                    { 838, 55, false, "Croma" },
                    { 839, 55, false, "Doblo" },
                    { 840, 55, false, "Ducato" },
                    { 841, 55, false, "Fiorino" },
                    { 842, 55, false, "Freemont" },
                    { 843, 55, false, "Idea" },
                    { 844, 55, false, "Linea" },
                    { 845, 55, false, "Marea" },
                    { 846, 55, false, "Multipla" },
                    { 847, 55, false, "Palio" },
                    { 848, 55, false, "Panda" },
                    { 849, 55, false, "Punto" },
                    { 850, 55, false, "Qubo" },
                    { 851, 55, false, "Scudo" },
                    { 852, 55, false, "Sedici" },
                    { 853, 55, false, "Seicento" },
                    { 854, 55, false, "Siena" },
                    { 855, 55, false, "Stilo" },
                    { 856, 55, false, "Strada" },
                    { 857, 55, false, "Tempra" },
                    { 858, 55, false, "Tipo" },
                    { 859, 55, false, "Ulysse" },
                    { 860, 55, false, "Uno" },
                    { 861, 56, false, "Ocean" },
                    { 862, 57, false, "Aerostar" },
                    { 863, 57, false, "Aspire" },
                    { 864, 57, false, "B-Max" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 865, 57, false, "Bronco" },
                    { 866, 57, false, "Bronco Sport" },
                    { 867, 57, false, "Bronco-II" },
                    { 868, 57, false, "C-Max" },
                    { 869, 57, false, "Capri" },
                    { 870, 57, false, "Contour" },
                    { 871, 57, false, "Cougar" },
                    { 872, 57, false, "Courier Van" },
                    { 873, 57, false, "Crown Victoria" },
                    { 874, 57, false, "E-series" },
                    { 875, 57, false, "Econonline" },
                    { 876, 57, false, "Econovan" },
                    { 877, 57, false, "EcoSport" },
                    { 878, 57, false, "Edge" },
                    { 879, 57, false, "Equator" },
                    { 880, 57, false, "Escape" },
                    { 881, 57, false, "Escort" },
                    { 882, 57, false, "Escort (North America)" },
                    { 883, 57, false, "Everest" },
                    { 884, 57, false, "Evos" },
                    { 885, 57, false, "Excursion" },
                    { 886, 57, false, "Expedition" },
                    { 887, 57, false, "Explorer" },
                    { 888, 57, false, "Explorer Sport Trac" },
                    { 889, 57, false, "F-Series" },
                    { 890, 57, false, "Festiva" },
                    { 891, 57, false, "Fiesta" },
                    { 892, 57, false, "Five Hundred" },
                    { 893, 57, false, "Flex" },
                    { 894, 57, false, "Focus" },
                    { 895, 57, false, "Freda" },
                    { 896, 57, false, "Freestyle" },
                    { 897, 57, false, "Fusion" },
                    { 898, 57, false, "Fusion (North America)" },
                    { 899, 57, false, "Galaxy" },
                    { 900, 57, false, "Granada" },
                    { 901, 57, false, "GT" },
                    { 902, 57, false, "Ixion" },
                    { 903, 57, false, "KA" },
                    { 904, 57, false, "Kuga" },
                    { 905, 57, false, "Laser" },
                    { 906, 57, false, "Maverick" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 907, 57, false, "Mondeo" },
                    { 908, 57, false, "Mustang" },
                    { 909, 57, false, "Mustang Mach-E" },
                    { 910, 57, false, "Orion" },
                    { 911, 57, false, "Otosan P100" },
                    { 912, 57, false, "Probe" },
                    { 913, 57, false, "Puma" },
                    { 914, 57, false, "Ranger" },
                    { 915, 57, false, "Ranger (North America)" },
                    { 916, 57, false, "S-Max" },
                    { 917, 57, false, "Scorpio" },
                    { 918, 57, false, "Sierra" },
                    { 919, 57, false, "Taunus" },
                    { 920, 57, false, "Taurus" },
                    { 921, 57, false, "Telstar" },
                    { 922, 57, false, "Tempo" },
                    { 923, 57, false, "Territory" },
                    { 924, 57, false, "Thunderbird" },
                    { 925, 57, false, "Torino" },
                    { 926, 57, false, "Tourneo Connect" },
                    { 927, 57, false, "Tourneo Custom" },
                    { 928, 57, false, "Transit" },
                    { 929, 57, false, "Transict Connect" },
                    { 930, 57, false, "Windstar" },
                    { 931, 58, false, "Lingzhi M5" },
                    { 932, 58, false, "T5 EVO" },
                    { 933, 59, false, "Alpha" },
                    { 934, 59, false, "Gratour" },
                    { 935, 59, false, "Saga" },
                    { 936, 59, false, "Sauvana" },
                    { 937, 59, false, "Sup" },
                    { 938, 59, false, "Tunland" },
                    { 939, 59, false, "View" },
                    { 940, 60, false, "Aion Hyper GT" },
                    { 941, 60, false, "Aion LX" },
                    { 942, 60, false, "Aion S" },
                    { 943, 60, false, "Aion V" },
                    { 944, 60, false, "Aion Y" },
                    { 945, 60, false, "E9" },
                    { 946, 60, false, "Emkoo" },
                    { 947, 60, false, "Empow" },
                    { 948, 60, false, "GN8" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 949, 60, false, "GS3" },
                    { 950, 60, false, "GS4" },
                    { 951, 60, false, "GS5" },
                    { 952, 60, false, "GS7" },
                    { 953, 60, false, "GS8" },
                    { 954, 60, false, "M6" },
                    { 955, 60, false, "M8" },
                    { 956, 61, false, "Atlas" },
                    { 957, 61, false, "Azkarra" },
                    { 958, 61, false, "Beauty Leopard" },
                    { 959, 61, false, "Binrui Cool" },
                    { 960, 61, false, "Binyue" },
                    { 961, 61, false, "CK" },
                    { 962, 61, false, "Coolray" },
                    { 963, 61, false, "Emgrand" },
                    { 964, 61, false, "Emgrand 7" },
                    { 965, 61, false, "Emgrand EC7" },
                    { 966, 61, false, "Emgrand EC8" },
                    { 967, 61, false, "Emgrand GSe" },
                    { 968, 61, false, "Emgrand GT" },
                    { 969, 61, false, "Emgrand L" },
                    { 970, 61, false, "Emgrand X7" },
                    { 971, 61, false, "Farizon FX" },
                    { 972, 61, false, "FC" },
                    { 973, 61, false, "Galaxy E5" },
                    { 974, 61, false, "Galaxy E8" },
                    { 975, 61, false, "Galaxy L6" },
                    { 976, 61, false, "Galaxy L7" },
                    { 977, 61, false, "Galaxy Starship 7" },
                    { 978, 61, false, "GC6" },
                    { 979, 61, false, "GC9" },
                    { 980, 61, false, "Geome Xingyuan" },
                    { 981, 61, false, "Geometry A GE11" },
                    { 982, 61, false, "Geometry E" },
                    { 983, 61, false, "Icon" },
                    { 984, 61, false, "Jiajii" },
                    { 985, 61, false, "MK" },
                    { 986, 61, false, "Monjaro" },
                    { 987, 61, false, "Okavango" },
                    { 988, 61, false, "Preface" },
                    { 989, 61, false, "SC7" },
                    { 990, 61, false, "Tugella" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 991, 61, false, "Vision X3" },
                    { 992, 61, false, "Vision X3 Pro" },
                    { 993, 61, false, "Vision X6 Pro" },
                    { 994, 62, false, "G70" },
                    { 995, 62, false, "G80" },
                    { 996, 62, false, "G90" },
                    { 997, 62, false, "GV60" },
                    { 998, 62, false, "GV70" },
                    { 999, 62, false, "GV80" },
                    { 1000, 62, false, "GV80 Coupe" },
                    { 1001, 63, false, "Acadia" },
                    { 1002, 63, false, "Canyon" },
                    { 1003, 63, false, "Envoy" },
                    { 1004, 63, false, "Hummer EV" },
                    { 1005, 63, false, "Jimmy" },
                    { 1006, 63, false, "Safari" },
                    { 1007, 63, false, "Savana" },
                    { 1008, 63, false, "Sierra" },
                    { 1009, 63, false, "Sonoma" },
                    { 1010, 63, false, "Terrain" },
                    { 1011, 63, false, "Vandura" },
                    { 1012, 63, false, "Yukon" },
                    { 1013, 64, false, "Aoxuan" },
                    { 1014, 64, false, "GX6" },
                    { 1015, 64, false, "Victor" },
                    { 1016, 65, false, "Coolbear" },
                    { 1017, 65, false, "Cowry" },
                    { 1018, 65, false, "Deer" },
                    { 1019, 65, false, "Florid" },
                    { 1020, 65, false, "Hover" },
                    { 1021, 65, false, "Hover H3" },
                    { 1022, 65, false, "Hover H5" },
                    { 1023, 65, false, "Hover H6" },
                    { 1024, 65, false, "Hover M2" },
                    { 1025, 65, false, "Hover M4" },
                    { 1026, 65, false, "Pegasus" },
                    { 1027, 65, false, "Peri" },
                    { 1028, 65, false, "Poer" },
                    { 1029, 65, false, "Poer KingKong" },
                    { 1030, 65, false, "Safe" },
                    { 1031, 65, false, "Sailor" },
                    { 1032, 65, false, "Sing RUV" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1033, 65, false, "Voleex C30" },
                    { 1034, 65, false, "Voleex C50" },
                    { 1035, 65, false, "Voleex C70" },
                    { 1036, 65, false, "Wingle 3" },
                    { 1037, 65, false, "Wingle 5" },
                    { 1038, 65, false, "Wingle 6" },
                    { 1039, 65, false, "Wingle 7" },
                    { 1040, 66, false, "Jun Xing" },
                    { 1041, 67, false, "Brio" },
                    { 1042, 67, false, "Princip" },
                    { 1043, 67, false, "Saibao" },
                    { 1044, 67, false, "Simbo" },
                    { 1045, 68, false, "2" },
                    { 1046, 68, false, "3" },
                    { 1047, 68, false, "7" },
                    { 1048, 68, false, "M3" },
                    { 1049, 68, false, "S5" },
                    { 1050, 69, false, "V7" },
                    { 1051, 69, false, "X5 EV" },
                    { 1052, 69, false, "X7" },
                    { 1053, 70, false, "Chitu" },
                    { 1054, 70, false, "Dargo" },
                    { 1055, 70, false, "Dargo X" },
                    { 1056, 70, false, "F7" },
                    { 1057, 70, false, "F7x" },
                    { 1058, 70, false, "H2" },
                    { 1059, 70, false, "H5" },
                    { 1060, 70, false, "H6" },
                    { 1061, 70, false, "H6 GT" },
                    { 1062, 70, false, "H7" },
                    { 1063, 70, false, "H8" },
                    { 1064, 70, false, "H9" },
                    { 1065, 70, false, "Jolion" },
                    { 1066, 70, false, "M6" },
                    { 1067, 70, false, "Raptor" },
                    { 1068, 70, false, "Shenshou" },
                    { 1069, 70, false, "Xiaolong" },
                    { 1070, 71, false, "Boliger" },
                    { 1071, 72, false, "X" },
                    { 1072, 72, false, "Y" },
                    { 1073, 72, false, "Z" },
                    { 1074, 73, false, "Accord" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1075, 73, false, "Acty" },
                    { 1076, 73, false, "Airwave" },
                    { 1077, 73, false, "Amaze" },
                    { 1078, 73, false, "Ascot" },
                    { 1079, 73, false, "Avancier" },
                    { 1080, 73, false, "Ballade" },
                    { 1081, 73, false, "Beat" },
                    { 1082, 73, false, "Brio" },
                    { 1083, 73, false, "Capa" },
                    { 1084, 73, false, "City" },
                    { 1085, 73, false, "Civic" },
                    { 1086, 73, false, "Clarity" },
                    { 1087, 73, false, "Concerto" },
                    { 1088, 73, false, "CR-V" },
                    { 1089, 73, false, "CR-Z" },
                    { 1090, 73, false, "CRX" },
                    { 1091, 73, false, "Crossroad" },
                    { 1092, 73, false, "Crosstour" },
                    { 1093, 73, false, "CRX" },
                    { 1094, 73, false, "Domani" },
                    { 1095, 73, false, "Element" },
                    { 1096, 73, false, "Elysion" },
                    { 1097, 73, false, "EV Plus" },
                    { 1098, 73, false, "Fit" },
                    { 1099, 73, false, "Fit Aria" },
                    { 1100, 73, false, "FR-V" },
                    { 1101, 73, false, "Freed" },
                    { 1102, 73, false, "HR-V" },
                    { 1103, 73, false, "Insight" },
                    { 1104, 73, false, "Inspire" },
                    { 1105, 73, false, "Integra" },
                    { 1106, 73, false, "Jade" },
                    { 1107, 73, false, "Jazz" },
                    { 1108, 73, false, "Lagreat" },
                    { 1109, 73, false, "Legend" },
                    { 1110, 73, false, "Life" },
                    { 1111, 73, false, "Logo" },
                    { 1112, 73, false, "Mobilio" },
                    { 1113, 73, false, "N-Box" },
                    { 1114, 73, false, "N-One" },
                    { 1115, 73, false, "N-Van" },
                    { 1116, 73, false, "N-WGN" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1117, 73, false, "NSX" },
                    { 1118, 73, false, "Odyssey" },
                    { 1119, 73, false, "Orthia" },
                    { 1120, 73, false, "Partner" },
                    { 1121, 73, false, "Passport" },
                    { 1122, 73, false, "Pilot" },
                    { 1123, 73, false, "Prelude" },
                    { 1124, 73, false, "Quintet" },
                    { 1125, 73, false, "Ridgeline" },
                    { 1126, 73, false, "S2000" },
                    { 1127, 73, false, "S660" },
                    { 1128, 73, false, "Shuttle" },
                    { 1129, 73, false, "SM-X" },
                    { 1130, 73, false, "Stepwgn" },
                    { 1131, 73, false, "Stream" },
                    { 1132, 73, false, "Thats" },
                    { 1133, 73, false, "Today" },
                    { 1134, 73, false, "Torneo" },
                    { 1135, 73, false, "Vamos" },
                    { 1136, 73, false, "Vezel" },
                    { 1137, 73, false, "Zest" },
                    { 1138, 74, false, "E-HS3" },
                    { 1139, 74, false, "E-HS9" },
                    { 1140, 74, false, "E-QM5" },
                    { 1141, 74, false, "H5" },
                    { 1142, 74, false, "H7" },
                    { 1143, 74, false, "H9" },
                    { 1144, 74, false, "HS5" },
                    { 1145, 74, false, "HS7" },
                    { 1146, 74, false, "HS9" },
                    { 1147, 74, false, "L5" },
                    { 1148, 74, false, "S9" },
                    { 1149, 75, false, "Neta Aya" },
                    { 1150, 75, false, "Neta GT" },
                    { 1151, 75, false, "Neta L" },
                    { 1152, 75, false, "Neta S" },
                    { 1153, 75, false, "Neta U" },
                    { 1154, 75, false, "Neta U-II" },
                    { 1155, 75, false, "Neta V" },
                    { 1156, 75, false, "Neta X" },
                    { 1157, 76, false, "Antelope" },
                    { 1158, 76, false, "Aurora" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1159, 76, false, "Landscape" },
                    { 1160, 76, false, "Landscape F1" },
                    { 1161, 76, false, "Landscape V3" },
                    { 1162, 76, false, "Major" },
                    { 1163, 76, false, "N7" },
                    { 1164, 76, false, "Navigator" },
                    { 1165, 76, false, "Plutus" },
                    { 1166, 77, false, "H5" },
                    { 1167, 78, false, "Stelato S9" },
                    { 1168, 79, false, "H1" },
                    { 1169, 79, false, "H2" },
                    { 1170, 79, false, "H3" },
                    { 1171, 80, false, "Accent" },
                    { 1172, 80, false, "Atos" },
                    { 1173, 80, false, "Avante" },
                    { 1174, 80, false, "Azera" },
                    { 1175, 80, false, "Centennial" },
                    { 1176, 80, false, "Click" },
                    { 1177, 80, false, "Creta" },
                    { 1178, 80, false, "Dynasty" },
                    { 1179, 80, false, "Elantra" },
                    { 1180, 80, false, "Entourage" },
                    { 1181, 80, false, "Eon" },
                    { 1182, 80, false, "Equus" },
                    { 1183, 80, false, "Excel" },
                    { 1184, 80, false, "Genesis" },
                    { 1185, 80, false, "Getz" },
                    { 1186, 80, false, "Grandeur" },
                    { 1187, 80, false, "H-1" },
                    { 1188, 80, false, "H-100" },
                    { 1189, 80, false, "HB20" },
                    { 1190, 80, false, "i10" },
                    { 1191, 80, false, "i20" },
                    { 1192, 80, false, "i30" },
                    { 1193, 80, false, "i40" },
                    { 1194, 80, false, "Ioniq" },
                    { 1195, 80, false, "ix20" },
                    { 1196, 80, false, "ix35" },
                    { 1197, 80, false, "ix55" },
                    { 1198, 80, false, "Kona" },
                    { 1199, 80, false, "Lavita" },
                    { 1200, 80, false, "Marcia" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1201, 80, false, "Matrix" },
                    { 1202, 80, false, "Maxcruz" },
                    { 1203, 80, false, "Nexo" },
                    { 1204, 80, false, "Palisade" },
                    { 1205, 80, false, "Pony" },
                    { 1206, 80, false, "Porter" },
                    { 1207, 80, false, "Santa Fe" },
                    { 1208, 80, false, "Santamo" },
                    { 1209, 80, false, "S-Coupe" },
                    { 1210, 80, false, "Solaris" },
                    { 1211, 80, false, "Sonata" },
                    { 1212, 80, false, "Starex" },
                    { 1213, 80, false, "Stellar" },
                    { 1214, 80, false, "Terracan" },
                    { 1215, 80, false, "Tiburon" },
                    { 1216, 80, false, "Trajet" },
                    { 1217, 80, false, "Tucson" },
                    { 1218, 80, false, "Veloster" },
                    { 1219, 80, false, "Venue" },
                    { 1220, 80, false, "Veracruz" },
                    { 1221, 80, false, "Verna" },
                    { 1222, 80, false, "Visto" },
                    { 1223, 80, false, "Xcent" },
                    { 1224, 81, false, "03" },
                    { 1225, 82, false, "LS6" },
                    { 1226, 82, false, "LS7" },
                    { 1227, 83, false, "Grenadier" },
                    { 1228, 84, false, "EX25" },
                    { 1229, 84, false, "EX35" },
                    { 1230, 84, false, "EX37" },
                    { 1231, 84, false, "FX35" },
                    { 1232, 84, false, "FX37" },
                    { 1233, 84, false, "FX45" },
                    { 1234, 84, false, "FX50" },
                    { 1235, 84, false, "G20" },
                    { 1236, 84, false, "G25" },
                    { 1237, 84, false, "G35" },
                    { 1238, 84, false, "G37" },
                    { 1239, 84, false, "I30" },
                    { 1240, 84, false, "I35" },
                    { 1241, 84, false, "J30" },
                    { 1242, 84, false, "JX35" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1243, 84, false, "M25" },
                    { 1244, 84, false, "M30" },
                    { 1245, 84, false, "M35" },
                    { 1246, 84, false, "M37" },
                    { 1247, 84, false, "M45" },
                    { 1248, 84, false, "M56" },
                    { 1249, 84, false, "Q30" },
                    { 1250, 84, false, "Q40" },
                    { 1251, 84, false, "Q45" },
                    { 1252, 84, false, "Q50" },
                    { 1253, 84, false, "Q60" },
                    { 1254, 84, false, "Q70" },
                    { 1255, 84, false, "QX30" },
                    { 1256, 84, false, "QX4" },
                    { 1257, 84, false, "QX50" },
                    { 1258, 84, false, "QX56" },
                    { 1259, 84, false, "QX60" },
                    { 1260, 84, false, "QX70" },
                    { 1261, 84, false, "QX80" },
                    { 1262, 85, false, "Peugeot Pars" },
                    { 1263, 85, false, "Runna" },
                    { 1264, 85, false, "Samand" },
                    { 1265, 85, false, "Sarir" },
                    { 1266, 86, false, "Amigo" },
                    { 1267, 86, false, "Ascender" },
                    { 1268, 86, false, "Axiom" },
                    { 1269, 86, false, "Bighorn" },
                    { 1270, 86, false, "D-Max" },
                    { 1271, 86, false, "Fargo" },
                    { 1272, 86, false, "Faster" },
                    { 1273, 86, false, "Filly" },
                    { 1274, 86, false, "Florian" },
                    { 1275, 86, false, "Gemini" },
                    { 1276, 86, false, "Hombre" },
                    { 1277, 86, false, "Impulse" },
                    { 1278, 86, false, "KB" },
                    { 1279, 86, false, "MU" },
                    { 1280, 86, false, "MU-X" },
                    { 1281, 86, false, "Piazza" },
                    { 1282, 86, false, "Rodeo" },
                    { 1283, 86, false, "Trooper" },
                    { 1284, 86, false, "VehiCROSS" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1285, 86, false, "Wizard" },
                    { 1286, 87, false, "E-J7" },
                    { 1287, 87, false, "e-JS4" },
                    { 1288, 87, false, "HFC 1027 PickUp" },
                    { 1289, 87, false, "iEV7S" },
                    { 1290, 87, false, "iEVS4" },
                    { 1291, 87, false, "J2" },
                    { 1292, 87, false, "J3" },
                    { 1293, 87, false, "J5" },
                    { 1294, 87, false, "J6" },
                    { 1295, 87, false, "J7" },
                    { 1296, 87, false, "J7 Plus" },
                    { 1297, 87, false, "JS4" },
                    { 1298, 87, false, "JS5" },
                    { 1299, 87, false, "JS6" },
                    { 1300, 87, false, "JS8" },
                    { 1301, 87, false, "M1" },
                    { 1302, 87, false, "M4 (Refine)" },
                    { 1303, 87, false, "M5" },
                    { 1304, 87, false, "N35" },
                    { 1305, 87, false, "S1" },
                    { 1306, 87, false, "S2" },
                    { 1307, 87, false, "S3" },
                    { 1308, 87, false, "S3 Pro" },
                    { 1309, 87, false, "S5" },
                    { 1310, 87, false, "S7" },
                    { 1311, 87, false, "Sehol A5 Plus" },
                    { 1312, 87, false, "Sehol X8 Plus" },
                    { 1313, 87, false, "Sunray" },
                    { 1314, 87, false, "T6" },
                    { 1315, 87, false, "T8 Pro" },
                    { 1316, 87, false, "T9 Hunter" },
                    { 1317, 87, false, "Yttrium 3" },
                    { 1318, 88, false, "J7" },
                    { 1319, 88, false, "J8" },
                    { 1320, 89, false, "E-Pace" },
                    { 1321, 89, false, "F-Pace" },
                    { 1322, 89, false, "F-Type" },
                    { 1323, 89, false, "I-Pace" },
                    { 1324, 89, false, "S-Type" },
                    { 1325, 89, false, "X-Type" },
                    { 1326, 89, false, "XE" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1327, 89, false, "XF" },
                    { 1328, 89, false, "XJ" },
                    { 1329, 89, false, "XK" },
                    { 1330, 89, false, "XKR" },
                    { 1331, 90, false, "Cherokee" },
                    { 1332, 90, false, "CJ" },
                    { 1333, 90, false, "Commander" },
                    { 1334, 90, false, "Compass" },
                    { 1335, 90, false, "Gladiator" },
                    { 1336, 90, false, "Grand Cherokee" },
                    { 1337, 90, false, "Grand Wagoneer" },
                    { 1338, 90, false, "Liberty" },
                    { 1339, 90, false, "Patriot" },
                    { 1340, 90, false, "Renegade" },
                    { 1341, 90, false, "Wagoneer" },
                    { 1342, 90, false, "Wrangler" },
                    { 1343, 91, false, "Dashing" },
                    { 1344, 91, false, "Shanghai L7" },
                    { 1345, 91, false, "Shanghai L9" },
                    { 1346, 91, false, "T2" },
                    { 1347, 91, false, "Traveller" },
                    { 1348, 91, false, "X50" },
                    { 1349, 91, false, "X70" },
                    { 1350, 91, false, "X70 Plus" },
                    { 1351, 91, false, "X70 PRO" },
                    { 1352, 91, false, "X70S" },
                    { 1353, 91, false, "X90" },
                    { 1354, 91, false, "X90 Plus" },
                    { 1355, 91, false, "X95" },
                    { 1356, 92, false, "VA3" },
                    { 1357, 92, false, "VS5" },
                    { 1358, 92, false, "VS7" },
                    { 1359, 93, false, "Haise" },
                    { 1360, 93, false, "Hiace" },
                    { 1361, 93, false, "X30" },
                    { 1362, 94, false, "G6S" },
                    { 1363, 95, false, "Robo 01" },
                    { 1364, 96, false, "Baodian" },
                    { 1365, 96, false, "Dadao" },
                    { 1366, 96, false, "Vigus" },
                    { 1367, 96, false, "YunBa JX6504D" },
                    { 1368, 96, false, "Yusheng" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1369, 97, false, "E5" },
                    { 1370, 97, false, "X3" },
                    { 1371, 97, false, "X3 Pro" },
                    { 1372, 97, false, "X7 Kunlun" },
                    { 1373, 97, false, "Xuanjie Pro EV" },
                    { 1374, 98, false, "K60" },
                    { 1375, 98, false, "K60 EV" },
                    { 1376, 99, false, "Avella" },
                    { 1377, 99, false, "Besta" },
                    { 1378, 99, false, "Bongo" },
                    { 1379, 99, false, "Cadenza" },
                    { 1380, 99, false, "Capital" },
                    { 1381, 99, false, "Carens" },
                    { 1382, 99, false, "Carnival" },
                    { 1383, 99, false, "Carstar" },
                    { 1384, 99, false, "Cee'd" },
                    { 1385, 99, false, "Cerato" },
                    { 1386, 99, false, "Clarus" },
                    { 1387, 99, false, "Concord" },
                    { 1388, 99, false, "Credos" },
                    { 1389, 99, false, "Elan" },
                    { 1390, 99, false, "Enterprise" },
                    { 1391, 99, false, "EV5" },
                    { 1392, 99, false, "EV6" },
                    { 1393, 99, false, "EV9" },
                    { 1394, 99, false, "Forte" },
                    { 1395, 99, false, "Joice" },
                    { 1396, 99, false, "K3" },
                    { 1397, 99, false, "K4" },
                    { 1398, 99, false, "K5" },
                    { 1399, 99, false, "K7" },
                    { 1400, 99, false, "K8" },
                    { 1401, 99, false, "K9" },
                    { 1402, 99, false, "K900" },
                    { 1403, 99, false, "KX 1" },
                    { 1404, 99, false, "Magentis" },
                    { 1405, 99, false, "Mohave" },
                    { 1406, 99, false, "Morning" },
                    { 1407, 99, false, "Niro" },
                    { 1408, 99, false, "Opirus" },
                    { 1409, 99, false, "Optima" },
                    { 1410, 99, false, "Pegas" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1411, 99, false, "Picanto" },
                    { 1412, 99, false, "Potentia" },
                    { 1413, 99, false, "Pregio" },
                    { 1414, 99, false, "Pride" },
                    { 1415, 99, false, "ProCeed" },
                    { 1416, 99, false, "Quoris" },
                    { 1417, 99, false, "Ray" },
                    { 1418, 99, false, "Retona" },
                    { 1419, 99, false, "Rio" },
                    { 1420, 99, false, "Rio X-Line" },
                    { 1421, 99, false, "Rocsta" },
                    { 1422, 99, false, "Sedona" },
                    { 1423, 99, false, "Seltos" },
                    { 1424, 99, false, "Sephia" },
                    { 1425, 99, false, "Shuma" },
                    { 1426, 99, false, "Sonet" },
                    { 1427, 99, false, "Sorento" },
                    { 1428, 99, false, "Soul" },
                    { 1429, 99, false, "Spectra" },
                    { 1430, 99, false, "Sportage" },
                    { 1431, 99, false, "Stinger" },
                    { 1432, 99, false, "Stonic" },
                    { 1433, 99, false, "Telluride" },
                    { 1434, 99, false, "Topic" },
                    { 1435, 99, false, "Venga" },
                    { 1436, 99, false, "Visto" },
                    { 1437, 99, false, "X-Trek" },
                    { 1438, 99, false, "XCeed" },
                    { 1439, 100, false, "V7" },
                    { 1440, 101, false, "Aventador" },
                    { 1441, 101, false, "Centenario" },
                    { 1442, 101, false, "Countach" },
                    { 1443, 101, false, "Diablo" },
                    { 1444, 101, false, "Gallardo" },
                    { 1445, 101, false, "Huracan" },
                    { 1446, 101, false, "LM002" },
                    { 1447, 101, false, "Murcielago" },
                    { 1448, 101, false, "Reventon" },
                    { 1449, 101, false, "Revuelto" },
                    { 1450, 101, false, "Temerario" },
                    { 1451, 101, false, "Urus" },
                    { 1452, 102, false, "Beta" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1453, 102, false, "Dedra" },
                    { 1454, 102, false, "Delta" },
                    { 1455, 102, false, "Kappa" },
                    { 1456, 102, false, "Lybra" },
                    { 1457, 102, false, "Musa" },
                    { 1458, 102, false, "Phedra" },
                    { 1459, 102, false, "Prisma" },
                    { 1460, 102, false, "Thema" },
                    { 1461, 102, false, "Thesis" },
                    { 1462, 102, false, "Ypsilon" },
                    { 1463, 102, false, "Zeta" },
                    { 1464, 103, false, "Defender" },
                    { 1465, 103, false, "Discovery" },
                    { 1466, 103, false, "Discovery Sport" },
                    { 1467, 103, false, "Freelander" },
                    { 1468, 103, false, "LR2" },
                    { 1469, 103, false, "LR3" },
                    { 1470, 103, false, "LR4" },
                    { 1471, 103, false, "Range Rover" },
                    { 1472, 103, false, "Range Rover Evoque" },
                    { 1473, 103, false, "Range Rover Sport" },
                    { 1474, 103, false, "Range Rover Velar" },
                    { 1475, 104, false, "E3" },
                    { 1476, 105, false, "C01" },
                    { 1477, 105, false, "C11" },
                    { 1478, 105, false, "C16" },
                    { 1479, 105, false, "T03" },
                    { 1480, 105, false, "C10" },
                    { 1481, 106, false, "Coupe" },
                    { 1482, 107, false, "CT200h" },
                    { 1483, 107, false, "ES 200" },
                    { 1484, 107, false, "ES 250" },
                    { 1485, 107, false, "ES 300" },
                    { 1486, 107, false, "ES 300h" },
                    { 1487, 107, false, "ES 330" },
                    { 1488, 107, false, "ES 350" },
                    { 1489, 107, false, "GS 200t" },
                    { 1490, 107, false, "GS 250" },
                    { 1491, 107, false, "GS 300h" },
                    { 1492, 107, false, "GS 350" },
                    { 1493, 107, false, "GS 400" },
                    { 1494, 107, false, "GS 430" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1495, 107, false, "GS 450h" },
                    { 1496, 107, false, "GS 460" },
                    { 1497, 107, false, "GS-F" },
                    { 1498, 107, false, "GX 400" },
                    { 1499, 107, false, "GX 470" },
                    { 1500, 107, false, "GX 550" },
                    { 1501, 107, false, "HS" },
                    { 1502, 107, false, "IS 200" },
                    { 1503, 107, false, "IS 200t" },
                    { 1504, 107, false, "IS 220" },
                    { 1505, 107, false, "IS 250" },
                    { 1506, 107, false, "IS 300" },
                    { 1507, 107, false, "IS 350" },
                    { 1508, 107, false, "IS 500" },
                    { 1509, 107, false, "IS-F" },
                    { 1510, 107, false, "LS 350" },
                    { 1511, 107, false, "LS 400" },
                    { 1512, 107, false, "LS 430" },
                    { 1513, 107, false, "LS 460" },
                    { 1514, 107, false, "LS 500" },
                    { 1515, 107, false, "LS 500h" },
                    { 1516, 107, false, "LS 600h" },
                    { 1517, 107, false, "700" },
                    { 1518, 107, false, "LX 450" },
                    { 1519, 107, false, "LX 450d" },
                    { 1520, 107, false, "LX 470" },
                    { 1521, 107, false, "LX 570" },
                    { 1522, 107, false, "LX 600" },
                    { 1523, 107, false, "LX 700h" },
                    { 1524, 107, false, "NX 200" },
                    { 1525, 107, false, "NX 200t" },
                    { 1526, 107, false, "NX 250" },
                    { 1527, 107, false, "NX 300" },
                    { 1528, 107, false, "NX 300h" },
                    { 1529, 107, false, "NX 350" },
                    { 1530, 107, false, "NX 350h" },
                    { 1531, 107, false, "NX 450h+" },
                    { 1532, 107, false, "RC 200t" },
                    { 1533, 107, false, "RC 300" },
                    { 1534, 107, false, "RC 300h" },
                    { 1535, 107, false, "RC 350" },
                    { 1536, 107, false, "RC-F" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1537, 107, false, "RX 200t" },
                    { 1538, 107, false, "RX 270" },
                    { 1539, 107, false, "RX 300" },
                    { 1540, 107, false, "RX 330" },
                    { 1541, 107, false, "RX350" },
                    { 1542, 107, false, "RX 350h" },
                    { 1543, 107, false, "RX 400h" },
                    { 1544, 107, false, "RX 350h" },
                    { 1545, 107, false, "RX 400h" },
                    { 1546, 107, false, "RX 450h" },
                    { 1547, 107, false, "RX 500h" },
                    { 1548, 107, false, "SC 300" },
                    { 1549, 107, false, "SC 400" },
                    { 1550, 107, false, "SC 430" },
                    { 1551, 107, false, "UX 200" },
                    { 1552, 107, false, "UX 250h" },
                    { 1553, 107, false, "UX300e" },
                    { 1554, 108, false, "L6" },
                    { 1555, 108, false, "L7" },
                    { 1556, 108, false, "L8" },
                    { 1557, 108, false, "L9" },
                    { 1558, 108, false, "Mega" },
                    { 1559, 108, false, "One" },
                    { 1560, 109, false, "Breez" },
                    { 1561, 109, false, "Cebrium" },
                    { 1562, 109, false, "Celliya" },
                    { 1563, 109, false, "Murman" },
                    { 1564, 109, false, "MyWay" },
                    { 1565, 109, false, "Smily" },
                    { 1566, 109, false, "Solano" },
                    { 1567, 109, false, "X50" },
                    { 1568, 109, false, "X60" },
                    { 1569, 109, false, "X70" },
                    { 1570, 109, false, "X80" },
                    { 1571, 110, false, "Aviator" },
                    { 1572, 110, false, "Continental" },
                    { 1573, 110, false, "Corsair" },
                    { 1574, 110, false, "LS" },
                    { 1575, 110, false, "Mark LT" },
                    { 1576, 110, false, "Mark VII" },
                    { 1577, 110, false, "MKC" },
                    { 1578, 110, false, "MKS" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1579, 110, false, "MKX" },
                    { 1580, 110, false, "MKZ" },
                    { 1581, 110, false, "Nautilus" },
                    { 1582, 110, false, "Navigator" },
                    { 1583, 110, false, "Town Car" },
                    { 1584, 110, false, "Zephyr" },
                    { 1585, 111, false, "7" },
                    { 1586, 111, false, "S6 Pro" },
                    { 1587, 111, false, "X3 Pro" },
                    { 1588, 111, false, "X6 Pro" },
                    { 1589, 112, false, "Elan" },
                    { 1590, 112, false, "Eletre" },
                    { 1591, 112, false, "Elise" },
                    { 1592, 112, false, "Emeya" },
                    { 1593, 112, false, "Esprit" },
                    { 1594, 112, false, "Europa S" },
                    { 1595, 112, false, "Evora" },
                    { 1596, 112, false, "Excel" },
                    { 1597, 112, false, "Exige" },
                    { 1598, 113, false, "Air" },
                    { 1599, 113, false, "Gravity" },
                    { 1600, 114, false, "R7" },
                    { 1601, 114, false, "S7" },
                    { 1602, 115, false, "5" },
                    { 1603, 115, false, "7" },
                    { 1604, 115, false, "U6 Turbo" },
                    { 1605, 115, false, "U7 Turbo" },
                    { 1606, 116, false, "01" },
                    { 1607, 116, false, "03" },
                    { 1608, 116, false, "05" },
                    { 1609, 116, false, "06" },
                    { 1610, 116, false, "07" },
                    { 1611, 116, false, "08 EM-P" },
                    { 1612, 116, false, "09" },
                    { 1613, 117, false, "Scorpio" },
                    { 1614, 118, false, "Leaf 80V" },
                    { 1615, 119, false, "228" },
                    { 1616, 119, false, "3200 GT" },
                    { 1617, 119, false, "4200 GT" },
                    { 1618, 119, false, "Coupe" },
                    { 1619, 119, false, "Ghibli" },
                    { 1620, 119, false, "GranCabrio" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1621, 119, false, "GranSport" },
                    { 1622, 119, false, "GranTurismo" },
                    { 1623, 119, false, "Grecale" },
                    { 1624, 119, false, "Levante" },
                    { 1625, 119, false, "MC20" },
                    { 1626, 119, false, "Quattroporte" },
                    { 1627, 119, false, "Shamal" },
                    { 1628, 119, false, "Spyder" },
                    { 1629, 120, false, "EV30" },
                    { 1630, 120, false, "G10" },
                    { 1631, 120, false, "G50" },
                    { 1632, 120, false, "G90" },
                    { 1633, 121, false, "57" },
                    { 1634, 121, false, "62" },
                    { 1635, 121, false, "Exelero" },
                    { 1636, 121, false, "Landaulet" },
                    { 1637, 121, false, "Zeppelin" },
                    { 1638, 122, false, "121" },
                    { 1639, 122, false, "2" },
                    { 1640, 122, false, "3" },
                    { 1641, 122, false, "323" },
                    { 1642, 122, false, "5" },
                    { 1643, 122, false, "6" },
                    { 1644, 122, false, "626" },
                    { 1645, 122, false, "929" },
                    { 1646, 122, false, "Atenza" },
                    { 1647, 122, false, "Axela" },
                    { 1648, 122, false, "AZ-1" },
                    { 1649, 122, false, "B-series" },
                    { 1650, 122, false, "Biante" },
                    { 1651, 122, false, "Bongo" },
                    { 1652, 122, false, "Bongo-Friendee" },
                    { 1653, 122, false, "BT-50" },
                    { 1654, 122, false, "Capella" },
                    { 1655, 122, false, "Carol" },
                    { 1656, 122, false, "Cosmo" },
                    { 1657, 122, false, "Cronos" },
                    { 1658, 122, false, "CX-3" },
                    { 1659, 122, false, "CX-30" },
                    { 1660, 122, false, "CX-4" },
                    { 1661, 122, false, "CX-5" },
                    { 1662, 122, false, "CX-7" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1663, 122, false, "CX-9" },
                    { 1664, 122, false, "CX-90" },
                    { 1665, 122, false, "Demio" },
                    { 1666, 122, false, "Efini MS-6" },
                    { 1667, 122, false, "Efini MS-8" },
                    { 1668, 122, false, "Efini MS-9" },
                    { 1669, 122, false, "Eunos 500" },
                    { 1670, 122, false, "Eunos 800" },
                    { 1671, 122, false, "EZ-6" },
                    { 1672, 122, false, "Familia" },
                    { 1673, 122, false, "Lantis" },
                    { 1674, 122, false, "Laputa" },
                    { 1675, 122, false, "Luce" },
                    { 1676, 122, false, "Millenia" },
                    { 1677, 122, false, "MPV" },
                    { 1678, 122, false, "MX-3" },
                    { 1679, 122, false, "MX-5" },
                    { 1680, 122, false, "MX-6" },
                    { 1681, 122, false, "MX30" },
                    { 1682, 122, false, "Navajo" },
                    { 1683, 122, false, "Premacy" },
                    { 1684, 122, false, "Proceed" },
                    { 1685, 122, false, "Proceed Levante" },
                    { 1686, 122, false, "Proceed Marvie" },
                    { 1687, 122, false, "Protege" },
                    { 1688, 122, false, "Roadster" },
                    { 1689, 122, false, "RX-7" },
                    { 1690, 122, false, "RX-8" },
                    { 1691, 122, false, "Sentia" },
                    { 1692, 122, false, "Tribute" },
                    { 1693, 122, false, "Verisa" },
                    { 1694, 122, false, "Xedos 6" },
                    { 1695, 122, false, "Xedos 9" },
                    { 1696, 123, false, "570S" },
                    { 1697, 123, false, "720S" },
                    { 1698, 123, false, "Senna" },
                    { 1699, 124, false, "A140" },
                    { 1700, 124, false, "A150" },
                    { 1701, 124, false, "A 160" },
                    { 1702, 124, false, "A 170" },
                    { 1703, 124, false, "A 180" },
                    { 1704, 124, false, "A 190" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1705, 124, false, "A 200" },
                    { 1706, 124, false, "A 210" },
                    { 1707, 124, false, "A 220" },
                    { 1708, 124, false, "A 250" },
                    { 1709, 124, false, "A 35 AMG" },
                    { 1710, 124, false, "A 45 AMG" },
                    { 1711, 124, false, "B 150" },
                    { 1712, 124, false, "B 160" },
                    { 1713, 124, false, "B 170" },
                    { 1714, 124, false, "B 180" },
                    { 1715, 124, false, "B 200" },
                    { 1716, 124, false, "B 220" },
                    { 1717, 124, false, "B 250" },
                    { 1718, 124, false, "C 160" },
                    { 1719, 124, false, "C 180" },
                    { 1720, 124, false, "C 200" },
                    { 1721, 124, false, "C 220" },
                    { 1722, 124, false, "C 230" },
                    { 1723, 124, false, "C 240" },
                    { 1724, 124, false, "C 250" },
                    { 1725, 124, false, "C 270" },
                    { 1726, 124, false, "C 280" },
                    { 1727, 124, false, "C 30 AMG" },
                    { 1728, 124, false, "C 300" },
                    { 1729, 124, false, "C 32 AMG" },
                    { 1730, 124, false, "C 320" },
                    { 1731, 124, false, "C 350" },
                    { 1732, 124, false, "C 36 AMG" },
                    { 1733, 124, false, "C 400" },
                    { 1734, 124, false, "C 43 AMG" },
                    { 1735, 124, false, "C 450 AMG" },
                    { 1736, 124, false, "C 55 AMG" },
                    { 1737, 124, false, "C 63 AMG" },
                    { 1738, 124, false, "CL 180" },
                    { 1739, 124, false, "CL 200" },
                    { 1740, 124, false, "CL 220" },
                    { 1741, 124, false, "CL 230" },
                    { 1742, 124, false, "CL 420" },
                    { 1743, 124, false, "CL 45 AMG" },
                    { 1744, 124, false, "CL 500" },
                    { 1745, 124, false, "CL 55 AMG" },
                    { 1746, 124, false, "CL 550" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1747, 124, false, "CL 600" },
                    { 1748, 124, false, "CL 63 AMG" },
                    { 1749, 124, false, "CL 65 AMG" },
                    { 1750, 124, false, "CLA 180" },
                    { 1751, 124, false, "CLA 200" },
                    { 1752, 124, false, "CLA 220" },
                    { 1753, 124, false, "CLA 250" },
                    { 1754, 124, false, "CLA 35 AMG" },
                    { 1755, 124, false, "CLA 45 AMG" },
                    { 1756, 124, false, "CLC 160" },
                    { 1757, 124, false, "CLC 180" },
                    { 1758, 124, false, "CLC 200" },
                    { 1759, 124, false, "CLC 220" },
                    { 1760, 124, false, "CLC 230" },
                    { 1761, 124, false, "CLC 350" },
                    { 1762, 124, false, "CLK 200" },
                    { 1763, 124, false, "CLK 220" },
                    { 1764, 124, false, "CLK 230" },
                    { 1765, 124, false, "CLK 240" },
                    { 1766, 124, false, "CLK 270" },
                    { 1767, 124, false, "CLK 280" },
                    { 1768, 124, false, "CLK 320" },
                    { 1769, 124, false, "CLK 350" },
                    { 1770, 124, false, "CLK 430" },
                    { 1771, 124, false, "CLK 500" },
                    { 1772, 124, false, "CLK 55 AMG" },
                    { 1773, 124, false, "CLK 63 AMG" },
                    { 1774, 124, false, "CLS 250" },
                    { 1775, 124, false, "CLS 280" },
                    { 1776, 124, false, "CLS 320" },
                    { 1777, 124, false, "CLS 350" },
                    { 1778, 124, false, "CLS 400" },
                    { 1779, 124, false, "CLS 450" },
                    { 1780, 124, false, "CLS 500" },
                    { 1781, 124, false, "CLS 53 AMG" },
                    { 1782, 124, false, "CLS 55 AMG" },
                    { 1783, 124, false, "CLS 550" },
                    { 1784, 124, false, "CLS 63 AMG" },
                    { 1785, 124, false, "E 200" },
                    { 1786, 124, false, "E 220" },
                    { 1787, 124, false, "E 230" },
                    { 1788, 124, false, "E 240" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1789, 124, false, "E 250" },
                    { 1790, 124, false, "E 260" },
                    { 1791, 124, false, "E 270" },
                    { 1792, 124, false, "E 280" },
                    { 1793, 124, false, "E 290" },
                    { 1794, 124, false, "E 300" },
                    { 1795, 124, false, "E 320" },
                    { 1796, 124, false, "E 350" },
                    { 1797, 124, false, "E 36 AMG" },
                    { 1798, 124, false, "E 400" },
                    { 1799, 124, false, "E 420" },
                    { 1800, 124, false, "E 43 AMG" },
                    { 1801, 124, false, "E 430" },
                    { 1802, 124, false, "E 450" },
                    { 1803, 124, false, "E 50" },
                    { 1804, 124, false, "E 500" },
                    { 1805, 124, false, "E 53 AMG" },
                    { 1806, 124, false, "E 55 AMG" },
                    { 1807, 124, false, "E 550" },
                    { 1808, 124, false, "E 60 AMG" },
                    { 1809, 124, false, "E 63 AMG" },
                    { 1810, 124, false, "EQA" },
                    { 1811, 124, false, "EQB" },
                    { 1812, 124, false, "EQC" },
                    { 1813, 124, false, "EQE" },
                    { 1814, 124, false, "EQE SUV" },
                    { 1815, 124, false, "EQS" },
                    { 1816, 124, false, "EQV" },
                    { 1817, 124, false, "G 230" },
                    { 1818, 124, false, "G 240" },
                    { 1819, 124, false, "G 250" },
                    { 1820, 124, false, "G 270" },
                    { 1821, 124, false, "G 280" },
                    { 1822, 124, false, "G 290" },
                    { 1823, 124, false, "G 300" },
                    { 1824, 124, false, "G 320" },
                    { 1825, 124, false, "G 350" },
                    { 1826, 124, false, "G 400" },
                    { 1827, 124, false, "G 500" },
                    { 1828, 124, false, "G 55 AMG" },
                    { 1829, 124, false, "G 550" },
                    { 1830, 124, false, "G 580 EQ" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1831, 124, false, "G 63 AMG" },
                    { 1832, 124, false, "G 65A AMG" },
                    { 1833, 124, false, "GL 320" },
                    { 1834, 124, false, "GL 350" },
                    { 1835, 124, false, "GL 400" },
                    { 1836, 124, false, "GL 420" },
                    { 1837, 124, false, "GL 450" },
                    { 1838, 124, false, "GL 500" },
                    { 1839, 124, false, "GL 55 AMG" },
                    { 1840, 124, false, "GL 550" },
                    { 1841, 124, false, "GL 63 AMG" },
                    { 1842, 124, false, "GLA 180" },
                    { 1843, 124, false, "GLA 200" },
                    { 1844, 124, false, "GLA 220" },
                    { 1845, 124, false, "GLA 250" },
                    { 1846, 124, false, "GLA 35 AMG" },
                    { 1847, 124, false, "GLA 45 AMG" },
                    { 1848, 124, false, "GLB 200" },
                    { 1849, 124, false, "GLB 220" },
                    { 1850, 124, false, "GLB 250" },
                    { 1851, 124, false, "GLB 35 AMG" },
                    { 1852, 124, false, "GLC Coupe 220" },
                    { 1853, 124, false, "GLC Coupe 250" },
                    { 1854, 124, false, "GLC Coupe 300" },
                    { 1855, 124, false, "GLC Coupe 43 AMG" },
                    { 1856, 124, false, "GLC Coupe 63 AMG" },
                    { 1857, 124, false, "GLC 200" },
                    { 1858, 124, false, "GLC 220" },
                    { 1859, 124, false, "GLC 250" },
                    { 1860, 124, false, "GLC 300" },
                    { 1861, 124, false, "GLC 350" },
                    { 1862, 124, false, "GLC 43 AMG" },
                    { 1863, 124, false, "GLC 63 AMG" },
                    { 1864, 124, false, "GLE Coupe 350d" },
                    { 1865, 124, false, "GLE Coupe 400" },
                    { 1866, 124, false, "GLE Coupe 43 AMG" },
                    { 1867, 124, false, "GLE Coupe 450 AMG" },
                    { 1868, 124, false, "GLE Coupe 53 AMG" },
                    { 1869, 124, false, "GLE Coupe 63 AMG" },
                    { 1870, 124, false, "GLE 250d" },
                    { 1871, 124, false, "GLE 300" },
                    { 1872, 124, false, "GLE 350" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1873, 124, false, "GLE 350d" },
                    { 1874, 124, false, "GLE 400" },
                    { 1875, 124, false, "GLE 43 AMG" },
                    { 1876, 124, false, "GLE 450" },
                    { 1877, 124, false, "GLE 500" },
                    { 1878, 124, false, "GLE 53 AMG" },
                    { 1879, 124, false, "GLE 580" },
                    { 1880, 124, false, "GLE 63 AMG" },
                    { 1881, 124, false, "GLK 200" },
                    { 1882, 124, false, "GLK 220" },
                    { 1883, 124, false, "GLK 250" },
                    { 1884, 124, false, "GLK 280" },
                    { 1885, 124, false, "GLK 300" },
                    { 1886, 124, false, "GLK 320" },
                    { 1887, 124, false, "GLK 350" },
                    { 1888, 124, false, "GLS 350d" },
                    { 1889, 124, false, "GLS 400" },
                    { 1890, 124, false, "GLS 450" },
                    { 1891, 124, false, "GLS 500" },
                    { 1892, 124, false, "GLS 580" },
                    { 1893, 124, false, "GLS 63 AMG" },
                    { 1894, 124, false, "MB 100" },
                    { 1895, 124, false, "ML 230" },
                    { 1896, 124, false, "ML 250" },
                    { 1897, 124, false, "ML 270" },
                    { 1898, 124, false, "ML 280" },
                    { 1899, 124, false, "ML 300" },
                    { 1900, 124, false, "ML 320" },
                    { 1901, 124, false, "ML 350" },
                    { 1902, 124, false, "ML 400" },
                    { 1903, 124, false, "ML 420" },
                    { 1904, 124, false, "ML 430" },
                    { 1905, 124, false, "ML 450" },
                    { 1906, 124, false, "ML 500" },
                    { 1907, 124, false, "ML 55 AMG" },
                    { 1908, 124, false, "ML 550" },
                    { 1909, 124, false, "ML 63 AMG" },
                    { 1910, 124, false, "R 280" },
                    { 1911, 124, false, "R 300" },
                    { 1912, 124, false, "R 320" },
                    { 1913, 124, false, "R 350" },
                    { 1914, 124, false, "R 500" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1915, 124, false, "R 63 AMG" },
                    { 1916, 124, false, "S 220" },
                    { 1917, 124, false, "S 250" },
                    { 1918, 124, false, "S 260" },
                    { 1919, 124, false, "S 280" },
                    { 1920, 124, false, "S 300" },
                    { 1921, 124, false, "S 320" },
                    { 1922, 124, false, "S 350" },
                    { 1923, 124, false, "S 380" },
                    { 1924, 124, false, "S 400" },
                    { 1925, 124, false, "S 420" },
                    { 1926, 124, false, "S 430" },
                    { 1927, 124, false, "S 450" },
                    { 1928, 124, false, "S 500" },
                    { 1929, 124, false, "S 55" },
                    { 1930, 124, false, "S 550" },
                    { 1931, 124, false, "S 560" },
                    { 1932, 124, false, "S 580" },
                    { 1933, 124, false, "S 600" },
                    { 1934, 124, false, "S 63 AMG" },
                    { 1935, 124, false, "S 65 AMG" },
                    { 1936, 124, false, "SEC 500 AMG" },
                    { 1937, 124, false, "450 SLC" },
                    { 1938, 124, false, "SL 280" },
                    { 1939, 124, false, "SL 300" },
                    { 1940, 124, false, "SL 320" },
                    { 1941, 124, false, "SL 350" },
                    { 1942, 124, false, "SL 380" },
                    { 1943, 124, false, "SL 400" },
                    { 1944, 124, false, "SL 450" },
                    { 1945, 124, false, "SL 500" },
                    { 1946, 124, false, "SL 55 AMG" },
                    { 1947, 124, false, "SL 560" },
                    { 1948, 124, false, "SL 60 AMG" },
                    { 1949, 124, false, "SL 600" },
                    { 1950, 124, false, "SL 63 AMG" },
                    { 1951, 124, false, "SL 65 AMG" },
                    { 1952, 124, false, "SL 70 AMG" },
                    { 1953, 124, false, "SL 73 AMG" },
                    { 1954, 124, false, "SLC 180" },
                    { 1955, 124, false, "SLC 200" },
                    { 1956, 124, false, "SLC 250" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1957, 124, false, "SLC 300" },
                    { 1958, 124, false, "SLC 43 AMG" },
                    { 1959, 124, false, "SLK 200" },
                    { 1960, 124, false, "SLK 230" },
                    { 1961, 124, false, "SLK 250" },
                    { 1962, 124, false, "SLK 280" },
                    { 1963, 124, false, "SLK 300" },
                    { 1964, 124, false, "SLK 32 AMG" },
                    { 1965, 124, false, "SLK 320" },
                    { 1966, 124, false, "SLK 350" },
                    { 1967, 124, false, "SLK 55 AMG" },
                    { 1968, 124, false, "SLR McLaren" },
                    { 1969, 124, false, "SLS AMG" },
                    { 1970, 124, false, "Sprinter" },
                    { 1971, 124, false, "V 200" },
                    { 1972, 124, false, "V 220" },
                    { 1973, 124, false, "V 230" },
                    { 1974, 124, false, "V250" },
                    { 1975, 124, false, "V 280" },
                    { 1976, 124, false, "V 300" },
                    { 1977, 124, false, "Vaneo" },
                    { 1978, 124, false, "Viano" },
                    { 1979, 124, false, "Vito" },
                    { 1980, 124, false, "X 200" },
                    { 1981, 124, false, "X 220" },
                    { 1982, 124, false, "X 250" },
                    { 1983, 124, false, "X 350" },
                    { 1984, 125, false, "G650 Landaulet Maybach" },
                    { 1985, 125, false, "GLS 600" },
                    { 1986, 125, false, "GLS 680" },
                    { 1987, 125, false, "S 400" },
                    { 1988, 125, false, "S 450" },
                    { 1989, 125, false, "S 500" },
                    { 1990, 125, false, "S 560" },
                    { 1991, 125, false, "S 580" },
                    { 1992, 125, false, "S 600" },
                    { 1993, 125, false, "S 650" },
                    { 1994, 125, false, "S 680" },
                    { 1995, 125, false, "VS 680" },
                    { 1996, 126, false, "Cougar" },
                    { 1997, 126, false, "Grand Marquis" },
                    { 1998, 126, false, "Marauder" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1999, 126, false, "Mariner" },
                    { 2000, 126, false, "Milan" },
                    { 2001, 126, false, "Montego" },
                    { 2002, 126, false, "Monterey" },
                    { 2003, 126, false, "Mounterey" },
                    { 2004, 126, false, "Mountaineer" },
                    { 2005, 126, false, "Mystique" },
                    { 2006, 126, false, "Sable" },
                    { 2007, 126, false, "Topaz" },
                    { 2008, 126, false, "Tracer" },
                    { 2009, 126, false, "Villager" },
                    { 2010, 127, false, "Metrocab I" },
                    { 2011, 127, false, "Metrocab II" },
                    { 2012, 128, false, "3" },
                    { 2013, 128, false, "350" },
                    { 2014, 128, false, "4 EV" },
                    { 2015, 128, false, "5" },
                    { 2016, 128, false, "550" },
                    { 2017, 128, false, "6" },
                    { 2018, 128, false, "6 Pro" },
                    { 2019, 128, false, "7" },
                    { 2020, 128, false, "750" },
                    { 2021, 128, false, "Cyberster" },
                    { 2022, 128, false, "F" },
                    { 2023, 128, false, "HS" },
                    { 2024, 128, false, "One" },
                    { 2025, 128, false, "RV8" },
                    { 2026, 128, false, "RX5" },
                    { 2027, 128, false, "T60" },
                    { 2028, 128, false, "TF" },
                    { 2029, 128, false, "Xpower SV" },
                    { 2030, 128, false, "ZR" },
                    { 2031, 128, false, "ZS" },
                    { 2032, 128, false, "ZT" },
                    { 2033, 129, false, "Cabrio" },
                    { 2034, 129, false, "Clubman" },
                    { 2035, 129, false, "Countryman" },
                    { 2036, 129, false, "Coupe" },
                    { 2037, 129, false, "Hatch" },
                    { 2038, 129, false, "Paceman" },
                    { 2039, 129, false, "Roadster" },
                    { 2040, 130, false, "3000 GT" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2041, 130, false, "Airtrek" },
                    { 2042, 130, false, "Aspire" },
                    { 2043, 130, false, "ASX" },
                    { 2044, 130, false, "Attrage" },
                    { 2045, 130, false, "Carisma" },
                    { 2046, 130, false, "Challenger" },
                    { 2047, 130, false, "Chariot" },
                    { 2048, 130, false, "Colt" },
                    { 2049, 130, false, "Cordia" },
                    { 2050, 130, false, "Debonair" },
                    { 2051, 130, false, "Delica" },
                    { 2052, 130, false, "Delica D:5" },
                    { 2053, 130, false, "Diamante" },
                    { 2054, 130, false, "Dingo" },
                    { 2055, 130, false, "Dion" },
                    { 2056, 130, false, "Eclipse" },
                    { 2057, 130, false, "Eclipse Cross" },
                    { 2058, 130, false, "eK Wagon" },
                    { 2059, 130, false, "Emeraude" },
                    { 2060, 130, false, "Endeavor" },
                    { 2061, 130, false, "Eterna" },
                    { 2062, 130, false, "FTO" },
                    { 2063, 130, false, "Galant" },
                    { 2064, 130, false, "Grandis" },
                    { 2065, 130, false, "GTO" },
                    { 2066, 130, false, "i" },
                    { 2067, 130, false, "i-MiEV" },
                    { 2068, 130, false, "Jeep" },
                    { 2069, 130, false, "L200" },
                    { 2070, 130, false, "L300" },
                    { 2071, 130, false, "L400" },
                    { 2072, 130, false, "Lancer" },
                    { 2073, 130, false, "Lancer Evolution" },
                    { 2074, 130, false, "Legnum" },
                    { 2075, 130, false, "Libero" },
                    { 2076, 130, false, "Minica" },
                    { 2077, 130, false, "Minicab MiEV" },
                    { 2078, 130, false, "Mirage" },
                    { 2079, 130, false, "Montero" },
                    { 2080, 130, false, "Montero Sport" },
                    { 2081, 130, false, "Nativa" },
                    { 2082, 130, false, "Outlander" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2083, 130, false, "Outlander Sport" },
                    { 2084, 130, false, "Pajero" },
                    { 2085, 130, false, "Pajero Evolution" },
                    { 2086, 130, false, "Pajerop iO" },
                    { 2087, 130, false, "Pajero Junior" },
                    { 2088, 130, false, "Pajero Mini" },
                    { 2089, 130, false, "Pajero Pinin" },
                    { 2090, 130, false, "Pajero Sport" },
                    { 2091, 130, false, "Proudia" },
                    { 2092, 130, false, "RVR" },
                    { 2093, 130, false, "Sapporo" },
                    { 2094, 130, false, "Sigma/Magna" },
                    { 2095, 130, false, "Space Gear" },
                    { 2096, 130, false, "Space Runner" },
                    { 2097, 130, false, "Space Star" },
                    { 2098, 130, false, "Space Wagon" },
                    { 2099, 130, false, "Starion" },
                    { 2100, 130, false, "Toppo" },
                    { 2101, 130, false, "Tredia" },
                    { 2102, 130, false, "Xpander" },
                    { 2103, 130, false, "Xpander Cross" },
                    { 2104, 130, false, "Zinger" },
                    { 2105, 131, false, "ES6" },
                    { 2106, 131, false, "ES7" },
                    { 2107, 131, false, "ES8" },
                    { 2108, 131, false, "ET7" },
                    { 2109, 132, false, "100NX" },
                    { 2110, 132, false, "180SX" },
                    { 2111, 132, false, "200SX" },
                    { 2112, 132, false, "240SX" },
                    { 2113, 132, false, "300ZX" },
                    { 2114, 132, false, "350ZX" },
                    { 2115, 132, false, "350Z" },
                    { 2116, 132, false, "370Z" },
                    { 2117, 132, false, "AD" },
                    { 2118, 132, false, "Almera" },
                    { 2119, 132, false, "Almera Classic" },
                    { 2120, 132, false, "Almera Tino" },
                    { 2121, 132, false, "Altima" },
                    { 2122, 132, false, "Ariya" },
                    { 2123, 132, false, "Armada" },
                    { 2124, 132, false, "Avenir" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2125, 132, false, "Bassara" },
                    { 2126, 132, false, "Bluebird" },
                    { 2127, 132, false, "Caravan" },
                    { 2128, 132, false, "Cedric" },
                    { 2129, 132, false, "Cefiro" },
                    { 2130, 132, false, "Cherry" },
                    { 2131, 132, false, "Cima" },
                    { 2132, 132, false, "Crew" },
                    { 2133, 132, false, "Cube" },
                    { 2134, 132, false, "Datsun" },
                    { 2135, 132, false, "Dayz" },
                    { 2136, 132, false, "Elgrand" },
                    { 2137, 132, false, "Expert" },
                    { 2138, 132, false, "Fairlady Z" },
                    { 2139, 132, false, "Frontier" },
                    { 2140, 132, false, "Fuga" },
                    { 2141, 132, false, "Gloria" },
                    { 2142, 132, false, "GT-R" },
                    { 2143, 132, false, "Homy" },
                    { 2144, 132, false, "Juke" },
                    { 2145, 132, false, "Kicks" },
                    { 2146, 132, false, "Kubistar" },
                    { 2147, 132, false, "Lafesta" },
                    { 2148, 132, false, "Largo" },
                    { 2149, 132, false, "Latio" },
                    { 2150, 132, false, "Laurel" },
                    { 2151, 132, false, "Leaf" },
                    { 2152, 132, false, "Leopard" },
                    { 2153, 132, false, "Liberty" },
                    { 2154, 132, false, "Lucino" },
                    { 2155, 132, false, "March" },
                    { 2156, 132, false, "Maxima" },
                    { 2157, 132, false, "Micra" },
                    { 2158, 132, false, "Mistral" },
                    { 2159, 132, false, "Moco" },
                    { 2160, 132, false, "Murano" },
                    { 2161, 132, false, "Navara" },
                    { 2162, 132, false, "Note" },
                    { 2163, 132, false, "NP300" },
                    { 2164, 132, false, "NV100 Clipper" },
                    { 2165, 132, false, "NV200" },
                    { 2166, 132, false, "NV350" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2167, 132, false, "Otti" },
                    { 2168, 132, false, "Pathfinder" },
                    { 2169, 132, false, "Patrol" },
                    { 2170, 132, false, "Pixo" },
                    { 2171, 132, false, "Prairie" },
                    { 2172, 132, false, "Prairie Joy" },
                    { 2173, 132, false, "Preage" },
                    { 2174, 132, false, "Presea" },
                    { 2175, 132, false, "President" },
                    { 2176, 132, false, "Primastar" },
                    { 2177, 132, false, "Primera" },
                    { 2178, 132, false, "Primera Camino" },
                    { 2179, 132, false, "Pulsar" },
                    { 2180, 132, false, "Qashqai" },
                    { 2181, 132, false, "Quest" },
                    { 2182, 132, false, "R'nessa" },
                    { 2183, 132, false, "Rasheen" },
                    { 2184, 132, false, "Rogue" },
                    { 2185, 132, false, "Roox" },
                    { 2186, 132, false, "Safari" },
                    { 2187, 132, false, "Sentra" },
                    { 2188, 132, false, "Serena" },
                    { 2189, 132, false, "Silvia" },
                    { 2190, 132, false, "Skyline" },
                    { 2191, 132, false, "Skyline Crossover" },
                    { 2192, 132, false, "Stagea" },
                    { 2193, 132, false, "Sunny" },
                    { 2194, 132, false, "Sylphy" },
                    { 2195, 132, false, "Teana" },
                    { 2196, 132, false, "Terra" },
                    { 2197, 132, false, "Terrano" },
                    { 2198, 132, false, "Tiida" },
                    { 2199, 132, false, "Tino" },
                    { 2200, 132, false, "Titan" },
                    { 2201, 132, false, "Urvan" },
                    { 2202, 132, false, "Vanette" },
                    { 2203, 132, false, "Versa" },
                    { 2204, 132, false, "Wingroad" },
                    { 2205, 132, false, "X-Terra" },
                    { 2206, 132, false, "X-Trail" },
                    { 2207, 132, false, "Xterra" },
                    { 2208, 133, false, "NV" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2209, 134, false, "F200" },
                    { 2210, 135, false, "88" },
                    { 2211, 135, false, "Achieva" },
                    { 2212, 135, false, "Alero" },
                    { 2213, 135, false, "Aurora" },
                    { 2214, 135, false, "Bravada" },
                    { 2215, 135, false, "Custom Cruiser" },
                    { 2216, 135, false, "Cutlass" },
                    { 2217, 135, false, "Intrigue" },
                    { 2218, 135, false, "Silhouette" },
                    { 2219, 136, false, "C5" },
                    { 2220, 136, false, "S5" },
                    { 2221, 137, false, "Adam" },
                    { 2222, 137, false, "Agila" },
                    { 2223, 137, false, "Ampera" },
                    { 2224, 137, false, "Antara" },
                    { 2225, 137, false, "Arena" },
                    { 2226, 137, false, "Ascona" },
                    { 2227, 137, false, "Astra" },
                    { 2228, 137, false, "Cabrio" },
                    { 2229, 137, false, "Calibra" },
                    { 2230, 137, false, "Campo" },
                    { 2231, 137, false, "Cascada" },
                    { 2232, 137, false, "Combo" },
                    { 2233, 137, false, "Corsa" },
                    { 2234, 137, false, "Crossland" },
                    { 2235, 137, false, "Frontera" },
                    { 2236, 137, false, "Grandland X" },
                    { 2237, 137, false, "GT" },
                    { 2238, 137, false, "Insignia" },
                    { 2239, 137, false, "Kadett" },
                    { 2240, 137, false, "Karl" },
                    { 2241, 137, false, "Manta" },
                    { 2242, 137, false, "Meriva" },
                    { 2243, 137, false, "Mokka" },
                    { 2244, 137, false, "Monterey" },
                    { 2245, 137, false, "Movano" },
                    { 2246, 137, false, "Omega" },
                    { 2247, 137, false, "Rekord" },
                    { 2248, 137, false, "Senator" },
                    { 2249, 137, false, "Signum" },
                    { 2250, 137, false, "Sintra" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2251, 137, false, "Speedster" },
                    { 2252, 137, false, "Tigra" },
                    { 2253, 137, false, "Vectra" },
                    { 2254, 137, false, "Vita" },
                    { 2255, 137, false, "Vivaro" },
                    { 2256, 137, false, "Zafira" },
                    { 2257, 137, false, "Zafira Life" },
                    { 2258, 138, false, "03" },
                    { 2259, 138, false, "Black Cat" },
                    { 2260, 138, false, "Good Cat" },
                    { 2261, 138, false, "Lightning Cat" },
                    { 2262, 138, false, "White Cat" },
                    { 2263, 139, false, "1007" },
                    { 2264, 139, false, "106" },
                    { 2265, 139, false, "107" },
                    { 2266, 139, false, "108" },
                    { 2267, 139, false, "2008" },
                    { 2268, 139, false, "205" },
                    { 2269, 139, false, "206" },
                    { 2270, 139, false, "207" },
                    { 2271, 139, false, "208" },
                    { 2272, 139, false, "3008" },
                    { 2273, 139, false, "301" },
                    { 2274, 139, false, "305" },
                    { 2275, 139, false, "306" },
                    { 2276, 139, false, "307" },
                    { 2277, 139, false, "308" },
                    { 2278, 139, false, "309" },
                    { 2279, 139, false, "4007" },
                    { 2280, 139, false, "4008" },
                    { 2281, 139, false, "405" },
                    { 2282, 139, false, "406" },
                    { 2283, 139, false, "407" },
                    { 2284, 139, false, "408" },
                    { 2285, 139, false, "5008" },
                    { 2286, 139, false, "505" },
                    { 2287, 139, false, "508" },
                    { 2288, 139, false, "605" },
                    { 2289, 139, false, "607" },
                    { 2290, 139, false, "806" },
                    { 2291, 139, false, "807" },
                    { 2292, 139, false, "Bipper" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2293, 139, false, "Boxer" },
                    { 2294, 139, false, "e-2008" },
                    { 2295, 139, false, "Expert" },
                    { 2296, 139, false, "iOn" },
                    { 2297, 139, false, "Partner" },
                    { 2298, 139, false, "RCZ" },
                    { 2299, 139, false, "Rifter" },
                    { 2300, 139, false, "Traveller" },
                    { 2301, 140, false, "Acclaim" },
                    { 2302, 140, false, "Breeze" },
                    { 2303, 140, false, "Fury" },
                    { 2304, 140, false, "Laser" },
                    { 2305, 140, false, "Neon" },
                    { 2306, 140, false, "Prowler" },
                    { 2307, 140, false, "Sundance" },
                    { 2308, 140, false, "Voyager" },
                    { 2309, 141, false, "Jishi 01" },
                    { 2310, 142, false, "2" },
                    { 2311, 142, false, "3" },
                    { 2312, 142, false, "4" },
                    { 2313, 143, false, "6000" },
                    { 2314, 143, false, "Aztek" },
                    { 2315, 143, false, "Bonneville" },
                    { 2316, 143, false, "Catalina" },
                    { 2317, 143, false, "Fiero" },
                    { 2318, 143, false, "Firebird" },
                    { 2319, 143, false, "G3" },
                    { 2320, 143, false, "G4" },
                    { 2321, 143, false, "G5" },
                    { 2322, 143, false, "G6" },
                    { 2323, 143, false, "G8" },
                    { 2324, 143, false, "Grand Am" },
                    { 2325, 143, false, "Grand Prix" },
                    { 2326, 143, false, "GTO" },
                    { 2327, 143, false, "LeMans" },
                    { 2328, 143, false, "Montana" },
                    { 2329, 143, false, "Parisienne" },
                    { 2330, 143, false, "Phoenix" },
                    { 2331, 143, false, "Pursuit" },
                    { 2332, 143, false, "Solstice" },
                    { 2333, 143, false, "Sunbird" },
                    { 2334, 143, false, "Sunfire" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2335, 143, false, "Torrent" },
                    { 2336, 143, false, "Trans Sport" },
                    { 2337, 143, false, "Vibe" },
                    { 2338, 144, false, "911" },
                    { 2339, 144, false, "918" },
                    { 2340, 144, false, "924" },
                    { 2341, 144, false, "928" },
                    { 2342, 144, false, "944" },
                    { 2343, 144, false, "968" },
                    { 2344, 144, false, "Boxster" },
                    { 2345, 144, false, "Carrera GT" },
                    { 2346, 144, false, "Cayenne" },
                    { 2347, 144, false, "Cayenne Coupe" },
                    { 2348, 144, false, "Cayman" },
                    { 2349, 144, false, "Macan" },
                    { 2350, 144, false, "Panamera" },
                    { 2351, 144, false, "Taycan" },
                    { 2352, 145, false, "Persona" },
                    { 2353, 146, false, "G" },
                    { 2354, 146, false, "Pinzgauer" },
                    { 2355, 147, false, "RD6" },
                    { 2356, 148, false, "1500" },
                    { 2357, 149, false, "Gentra" },
                    { 2358, 149, false, "Matiz" },
                    { 2359, 149, false, "Nexia R3" },
                    { 2360, 149, false, "R2" },
                    { 2361, 149, false, "R4" },
                    { 2362, 150, false, "11" },
                    { 2363, 150, false, "12" },
                    { 2364, 150, false, "14" },
                    { 2365, 150, false, "16" },
                    { 2366, 150, false, "18" },
                    { 2367, 150, false, "19" },
                    { 2368, 150, false, "20" },
                    { 2369, 150, false, "21" },
                    { 2370, 150, false, "25" },
                    { 2371, 150, false, "30" },
                    { 2372, 150, false, "5" },
                    { 2373, 150, false, "9" },
                    { 2374, 150, false, "Alaskan" },
                    { 2375, 150, false, "Arkana" },
                    { 2376, 150, false, "Avantime" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2377, 150, false, "Captur" },
                    { 2378, 150, false, "City K-ZE" },
                    { 2379, 150, false, "Clio" },
                    { 2380, 150, false, "Dokker" },
                    { 2381, 150, false, "Duster" },
                    { 2382, 150, false, "Espace" },
                    { 2383, 150, false, "Express" },
                    { 2384, 150, false, "Fluence" },
                    { 2385, 150, false, "Fuego" },
                    { 2386, 150, false, "Grand Scenic" },
                    { 2387, 150, false, "Kadjar" },
                    { 2388, 150, false, "Kangoo" },
                    { 2389, 150, false, "Kaptur" },
                    { 2390, 150, false, "Koleos" },
                    { 2391, 150, false, "Kwid" },
                    { 2392, 150, false, "Laguna" },
                    { 2393, 150, false, "Latitude" },
                    { 2394, 150, false, "Lodgy" },
                    { 2395, 150, false, "Logan" },
                    { 2396, 150, false, "Logan Stepway" },
                    { 2397, 150, false, "Mascott" },
                    { 2398, 150, false, "Master" },
                    { 2399, 150, false, "Megane" },
                    { 2400, 150, false, "Modus" },
                    { 2401, 150, false, "Rapid" },
                    { 2402, 150, false, "Safrane" },
                    { 2403, 150, false, "Sandero" },
                    { 2404, 150, false, "Sandero Stepway" },
                    { 2405, 150, false, "Scenic" },
                    { 2406, 150, false, "Symbol" },
                    { 2407, 150, false, "Talisman" },
                    { 2408, 150, false, "Trafic" },
                    { 2409, 150, false, "Twingo" },
                    { 2410, 150, false, "Twizy" },
                    { 2411, 150, false, "Vel Satis" },
                    { 2412, 150, false, "Wind" },
                    { 2413, 150, false, "Zoe" },
                    { 2414, 151, false, "QM3" },
                    { 2415, 151, false, "QM5" },
                    { 2416, 151, false, "QM6" },
                    { 2417, 151, false, "SM3" },
                    { 2418, 151, false, "SM5" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2419, 151, false, "SM6" },
                    { 2420, 151, false, "SM7" },
                    { 2421, 151, false, "XM3" },
                    { 2422, 152, false, "R1S" },
                    { 2423, 152, false, "R1T" },
                    { 2424, 153, false, "i5" },
                    { 2425, 153, false, "Marvel X" },
                    { 2426, 153, false, "RX5" },
                    { 2427, 154, false, "Corniche" },
                    { 2428, 154, false, "Cullinan" },
                    { 2429, 154, false, "Dawn" },
                    { 2430, 154, false, "Ghost" },
                    { 2431, 154, false, "Park Ward" },
                    { 2432, 154, false, "Phantom" },
                    { 2433, 154, false, "Silver Cloud" },
                    { 2434, 154, false, "Silver Seraph" },
                    { 2435, 154, false, "Silver Shadow" },
                    { 2436, 154, false, "Silver Spirit" },
                    { 2437, 154, false, "Silver Spur" },
                    { 2438, 154, false, "Spectre" },
                    { 2439, 154, false, "Wraith" },
                    { 2440, 155, false, "200 Series" },
                    { 2441, 155, false, "25" },
                    { 2442, 155, false, "400 Series" },
                    { 2443, 155, false, "45" },
                    { 2444, 155, false, "600 Series" },
                    { 2445, 155, false, "75" },
                    { 2446, 155, false, "800 Series" },
                    { 2447, 155, false, "CityRover" },
                    { 2448, 155, false, "Maestro" },
                    { 2449, 155, false, "Metro" },
                    { 2450, 155, false, "Mini" },
                    { 2451, 155, false, "Montego" },
                    { 2452, 155, false, "Streetwise" },
                    { 2453, 156, false, "01" },
                    { 2454, 157, false, "9-2X" },
                    { 2455, 157, false, "9-3" },
                    { 2456, 157, false, "9-5" },
                    { 2457, 157, false, "9-7X" },
                    { 2458, 157, false, "90" },
                    { 2459, 157, false, "900" },
                    { 2460, 157, false, "9000" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2461, 157, false, "99" },
                    { 2462, 158, false, "Maxus Dana V1" },
                    { 2463, 158, false, "Maxus EUNIQ 5" },
                    { 2464, 158, false, "Maxus V80" },
                    { 2465, 159, false, "PS-10" },
                    { 2466, 160, false, "Astra" },
                    { 2467, 160, false, "Aura" },
                    { 2468, 160, false, "Ion" },
                    { 2469, 160, false, "L-Series" },
                    { 2470, 160, false, "Outlook" },
                    { 2471, 160, false, "Relay" },
                    { 2472, 160, false, "S-Series" },
                    { 2473, 160, false, "Sky" },
                    { 2474, 160, false, "Vue" },
                    { 2475, 161, false, "Citigo" },
                    { 2476, 161, false, "Enyaq" },
                    { 2477, 161, false, "Fabia" },
                    { 2478, 161, false, "Favorit" },
                    { 2479, 161, false, "Felicia" },
                    { 2480, 161, false, "Forman" },
                    { 2481, 161, false, "Kamiq" },
                    { 2482, 161, false, "Karoq" },
                    { 2483, 161, false, "Kodiaq" },
                    { 2484, 161, false, "Octavia" },
                    { 2485, 161, false, "Rapid" },
                    { 2486, 161, false, "Roomster" },
                    { 2487, 161, false, "Scala" },
                    { 2488, 161, false, "Superb" },
                    { 2489, 161, false, "Yeti" },
                    { 2490, 162, false, "EQ" },
                    { 2491, 162, false, "Forfour" },
                    { 2492, 162, false, "Fortwo" },
                    { 2493, 163, false, "DX3" },
                    { 2494, 163, false, "DX5" },
                    { 2495, 163, false, "DX7" },
                    { 2496, 163, false, "DX9" },
                    { 2497, 163, false, "V3 Lingyue" },
                    { 2498, 163, false, "V5 Lingzhi" },
                    { 2499, 163, false, "V6 Lingshi" },
                    { 2500, 163, false, "V7 Lingzhi" },
                    { 2501, 163, false, "V9 Lingzhi" },
                    { 2502, 164, false, "2" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2503, 165, false, "Actyon" },
                    { 2504, 165, false, "Chairman" },
                    { 2505, 165, false, "Istana" },
                    { 2506, 165, false, "Korando" },
                    { 2507, 165, false, "Kyron" },
                    { 2508, 165, false, "Musso" },
                    { 2509, 165, false, "Rexton" },
                    { 2510, 165, false, "Rodius" },
                    { 2511, 165, false, "Stavic" },
                    { 2512, 165, false, "Tivoli" },
                    { 2513, 165, false, "XLV" },
                    { 2514, 166, false, "1000" },
                    { 2515, 166, false, "1400" },
                    { 2516, 166, false, "1600" },
                    { 2517, 166, false, "1800" },
                    { 2518, 166, false, "360" },
                    { 2519, 166, false, "600" },
                    { 2520, 166, false, "Alcyone" },
                    { 2521, 166, false, "Ascent" },
                    { 2522, 166, false, "Baja" },
                    { 2523, 166, false, "BRZ" },
                    { 2524, 166, false, "BRZ tS" },
                    { 2525, 166, false, "Crosstrek" },
                    { 2526, 166, false, "Dex" },
                    { 2527, 166, false, "Dias Wagon" },
                    { 2528, 166, false, "Domingo" },
                    { 2529, 166, false, "Exiga" },
                    { 2530, 166, false, "Forester" },
                    { 2531, 166, false, "Impreza" },
                    { 2532, 166, false, "Impreza WRX" },
                    { 2533, 166, false, "Impreza WRX STI" },
                    { 2534, 166, false, "Justy" },
                    { 2535, 166, false, "Legacy" },
                    { 2536, 166, false, "Leone" },
                    { 2537, 166, false, "Levorg" },
                    { 2538, 166, false, "Libero" },
                    { 2539, 166, false, "Outback" },
                    { 2540, 166, false, "Pleo" },
                    { 2541, 166, false, "R1" },
                    { 2542, 166, false, "R2" },
                    { 2543, 166, false, "Rex" },
                    { 2544, 166, false, "Sambar" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2545, 166, false, "Stella" },
                    { 2546, 166, false, "SVX" },
                    { 2547, 166, false, "Traviq" },
                    { 2548, 166, false, "Tribeca" },
                    { 2549, 166, false, "Viziv" },
                    { 2550, 166, false, "WRX" },
                    { 2551, 166, false, "WRX STI" },
                    { 2552, 166, false, "XV" },
                    { 2553, 167, false, "Alto" },
                    { 2554, 167, false, "APV" },
                    { 2555, 167, false, "Baleno" },
                    { 2556, 167, false, "Cappuccino" },
                    { 2557, 167, false, "Carry" },
                    { 2558, 167, false, "Celerio" },
                    { 2559, 167, false, "Cervo" },
                    { 2560, 167, false, "Cultus" },
                    { 2561, 167, false, "Ertiga" },
                    { 2562, 167, false, "Escudo" },
                    { 2563, 167, false, "Every" },
                    { 2564, 167, false, "Forenza" },
                    { 2565, 167, false, "Fronte" },
                    { 2566, 167, false, "Grand Vitara" },
                    { 2567, 167, false, "Ignis" },
                    { 2568, 167, false, "Jimny" },
                    { 2569, 167, false, "Kizashi" },
                    { 2570, 167, false, "Lapin" },
                    { 2571, 167, false, "Liana" },
                    { 2572, 167, false, "MR Wagon" },
                    { 2573, 167, false, "Reno" },
                    { 2574, 167, false, "Samurai" },
                    { 2575, 167, false, "Sidekick" },
                    { 2576, 167, false, "Solio" },
                    { 2577, 167, false, "Splash" },
                    { 2578, 167, false, "Swift" },
                    { 2579, 167, false, "SX4" },
                    { 2580, 167, false, "Twin" },
                    { 2581, 167, false, "Vitara" },
                    { 2582, 167, false, "Wagon R" },
                    { 2583, 167, false, "X-90" },
                    { 2584, 167, false, "XL7" },
                    { 2585, 168, false, "Tiger" },
                    { 2586, 169, false, "300" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2587, 169, false, "400" },
                    { 2588, 169, false, "500" },
                    { 2589, 169, false, "700" },
                    { 2590, 170, false, "Cybertruck" },
                    { 2591, 170, false, "Model 3" },
                    { 2592, 170, false, "Model S" },
                    { 2593, 170, false, "Model X" },
                    { 2594, 170, false, "Model Y" },
                    { 2595, 170, false, "Roadster" },
                    { 2596, 171, false, "4Runner" },
                    { 2597, 171, false, "86" },
                    { 2598, 171, false, "Allion" },
                    { 2599, 171, false, "Alphard" },
                    { 2600, 171, false, "Altezza" },
                    { 2601, 171, false, "Aristo" },
                    { 2602, 171, false, "Aurion" },
                    { 2603, 171, false, "Auris" },
                    { 2604, 171, false, "Avalon" },
                    { 2605, 171, false, "Avanza" },
                    { 2606, 171, false, "Avensis" },
                    { 2607, 171, false, "Aygo" },
                    { 2608, 171, false, "bB" },
                    { 2609, 171, false, "Belta" },
                    { 2610, 171, false, "Blade" },
                    { 2611, 171, false, "Brevis" },
                    { 2612, 171, false, "C-HR" },
                    { 2613, 171, false, "Caldina" },
                    { 2614, 171, false, "Camry" },
                    { 2615, 171, false, "Carina" },
                    { 2616, 171, false, "Carina E" },
                    { 2617, 171, false, "Cavalier" },
                    { 2618, 171, false, "Celica" },
                    { 2619, 171, false, "Celsior" },
                    { 2620, 171, false, "Century" },
                    { 2621, 171, false, "Chaser" },
                    { 2622, 171, false, "Coaster" },
                    { 2623, 171, false, "Comfort" },
                    { 2624, 171, false, "Corolla" },
                    { 2625, 171, false, "Corona" },
                    { 2626, 171, false, "Corsa" },
                    { 2627, 171, false, "Cressida" },
                    { 2628, 171, false, "Cresta" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2629, 171, false, "Crown" },
                    { 2630, 171, false, "Curren" },
                    { 2631, 171, false, "Cynos" },
                    { 2632, 171, false, "Duet" },
                    { 2633, 171, false, "Dyna" },
                    { 2634, 171, false, "Echo" },
                    { 2635, 171, false, "Estima" },
                    { 2636, 171, false, "FJ Cruiser" },
                    { 2637, 171, false, "Fortuner" },
                    { 2638, 171, false, "Fun Cargo" },
                    { 2639, 171, false, "Gaia" },
                    { 2640, 171, false, "Granvia" },
                    { 2641, 171, false, "Harrier" },
                    { 2642, 171, false, "Hiace" },
                    { 2643, 171, false, "Highlander" },
                    { 2644, 171, false, "Hilux" },
                    { 2645, 171, false, "Innova" },
                    { 2646, 171, false, "Ipsum" },
                    { 2647, 171, false, "iQ" },
                    { 2648, 171, false, "Isis" },
                    { 2649, 171, false, "Ist" },
                    { 2650, 171, false, "Kluger" },
                    { 2651, 171, false, "Land Cruiser" },
                    { 2652, 171, false, "LiteAce" },
                    { 2653, 171, false, "Mark II" },
                    { 2654, 171, false, "Mark X" },
                    { 2655, 171, false, "MasterAce" },
                    { 2656, 171, false, "Matrix" },
                    { 2657, 171, false, "Mirai" },
                    { 2658, 171, false, "MR2" },
                    { 2659, 171, false, "Nadia" },
                    { 2660, 171, false, "Noah" },
                    { 2661, 171, false, "Opa" },
                    { 2662, 171, false, "Paseo" },
                    { 2663, 171, false, "Passo" },
                    { 2664, 171, false, "Picnic" },
                    { 2665, 171, false, "Platz" },
                    { 2666, 171, false, "Porte" },
                    { 2667, 171, false, "Premio" },
                    { 2668, 171, false, "Previa" },
                    { 2669, 171, false, "Prius" },
                    { 2670, 171, false, "ProAce" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2671, 171, false, "Probox" },
                    { 2672, 171, false, "Progres" },
                    { 2673, 171, false, "Pronard" },
                    { 2674, 171, false, "Publica" },
                    { 2675, 171, false, "Quantum" },
                    { 2676, 171, false, "Ractis" },
                    { 2677, 171, false, "Raum" },
                    { 2678, 171, false, "RAV4" },
                    { 2679, 171, false, "RegiusAce" },
                    { 2680, 171, false, "Reiz" },
                    { 2681, 171, false, "Rukus" },
                    { 2682, 171, false, "Rush" },
                    { 2683, 171, false, "SAI" },
                    { 2684, 171, false, "Sequoia" },
                    { 2685, 171, false, "Sera" },
                    { 2686, 171, false, "Sienna" },
                    { 2687, 171, false, "Sienta" },
                    { 2688, 171, false, "Soarer" },
                    { 2689, 171, false, "Solara" },
                    { 2690, 171, false, "Soluna" },
                    { 2691, 171, false, "Space Cruiser" },
                    { 2692, 171, false, "Sparky" },
                    { 2693, 171, false, "Sprinter" },
                    { 2694, 171, false, "Stallion" },
                    { 2695, 171, false, "Starlet" },
                    { 2696, 171, false, "Succeed" },
                    { 2697, 171, false, "Supra" },
                    { 2698, 171, false, "T100" },
                    { 2699, 171, false, "Tacoma" },
                    { 2700, 171, false, "Tamaraw" },
                    { 2701, 171, false, "Tarago" },
                    { 2702, 171, false, "Tercel" },
                    { 2703, 171, false, "TownAce" },
                    { 2704, 171, false, "Tundra" },
                    { 2705, 171, false, "Urban Cruiser" },
                    { 2706, 171, false, "Vanguard" },
                    { 2707, 171, false, "Vellfire" },
                    { 2708, 171, false, "Venza" },
                    { 2709, 171, false, "Verossa" },
                    { 2710, 171, false, "Verso" },
                    { 2711, 171, false, "Vios" },
                    { 2712, 171, false, "Vista" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2713, 171, false, "Vitz" },
                    { 2714, 171, false, "Voltz" },
                    { 2715, 171, false, "Voxy" },
                    { 2716, 171, false, "Will" },
                    { 2717, 171, false, "Windom" },
                    { 2718, 171, false, "Wish" },
                    { 2719, 171, false, "Yaris" },
                    { 2720, 171, false, "Yaris Cross" },
                    { 2721, 172, false, "Amarok" },
                    { 2722, 172, false, "Arteon" },
                    { 2723, 172, false, "Atlas" },
                    { 2724, 172, false, "Beetle" },
                    { 2725, 172, false, "Bora" },
                    { 2726, 172, false, "Caddy" },
                    { 2727, 172, false, "Caravelle" },
                    { 2728, 172, false, "CC" },
                    { 2729, 172, false, "Corrado" },
                    { 2730, 172, false, "Crafter" },
                    { 2731, 172, false, "CrossFox" },
                    { 2732, 172, false, "Eos" },
                    { 2733, 172, false, "Fox" },
                    { 2734, 172, false, "Gol" },
                    { 2735, 172, false, "Golf" },
                    { 2736, 172, false, "ID.3" },
                    { 2737, 172, false, "ID.4" },
                    { 2738, 172, false, "ID.5" },
                    { 2739, 172, false, "ID.6" },
                    { 2740, 172, false, "Jetta" },
                    { 2741, 172, false, "Karmann Ghia" },
                    { 2742, 172, false, "Lavida" },
                    { 2743, 172, false, "LT" },
                    { 2744, 172, false, "Lupo" },
                    { 2745, 172, false, "Multivan" },
                    { 2746, 172, false, "Passat" },
                    { 2747, 172, false, "Phaeton" },
                    { 2748, 172, false, "Pointer" },
                    { 2749, 172, false, "Polo" },
                    { 2750, 172, false, "Quantum" },
                    { 2751, 172, false, "Routan" },
                    { 2752, 172, false, "Santana" },
                    { 2753, 172, false, "Scirocco" },
                    { 2754, 172, false, "Sharan" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2755, 172, false, "T-Cross" },
                    { 2756, 172, false, "T-Roc" },
                    { 2757, 172, false, "Taigun" },
                    { 2758, 172, false, "Taro" },
                    { 2759, 172, false, "Teramont" },
                    { 2760, 172, false, "Tiguan" },
                    { 2761, 172, false, "Touareg" },
                    { 2762, 172, false, "Touran" },
                    { 2763, 172, false, "Transporter" },
                    { 2764, 172, false, "Up" },
                    { 2765, 172, false, "Vento" },
                    { 2766, 173, false, "140" },
                    { 2767, 173, false, "164" },
                    { 2768, 173, false, "240" },
                    { 2769, 173, false, "260" },
                    { 2770, 173, false, "340" },
                    { 2771, 173, false, "360" },
                    { 2772, 173, false, "440" },
                    { 2773, 173, false, "460" },
                    { 2774, 173, false, "480" },
                    { 2775, 173, false, "66" },
                    { 2776, 173, false, "740" },
                    { 2777, 173, false, "760" },
                    { 2778, 173, false, "780" },
                    { 2779, 173, false, "850" },
                    { 2780, 173, false, "940" },
                    { 2781, 173, false, "960" },
                    { 2782, 173, false, "C30" },
                    { 2783, 173, false, "C70" },
                    { 2784, 173, false, "C90" },
                    { 2785, 173, false, "P1800" },
                    { 2786, 173, false, "P1900" },
                    { 2787, 173, false, "PV" },
                    { 2788, 173, false, "S40" },
                    { 2789, 173, false, "S60" },
                    { 2790, 173, false, "S70" },
                    { 2791, 173, false, "S80" },
                    { 2792, 173, false, "S90" },
                    { 2793, 173, false, "V40" },
                    { 2794, 173, false, "V50" },
                    { 2795, 173, false, "V60" },
                    { 2796, 173, false, "V70" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 2797, 173, false, "V90" },
                    { 2798, 173, false, "XC40" },
                    { 2799, 173, false, "XC60" },
                    { 2800, 173, false, "XC70" },
                    { 2801, 173, false, "XC90" },
                    { 2802, 174, false, "Chasing Light" },
                    { 2803, 174, false, "Dream" },
                    { 2804, 174, false, "Free" },
                    { 2805, 174, false, "i-Free" },
                    { 2806, 174, false, "i-Land" },
                    { 2807, 174, false, "i-SPACE" },
                    { 2808, 174, false, "i-V6" },
                    { 2809, 174, false, "i-V7" },
                    { 2810, 174, false, "i-V9" },
                    { 2811, 174, false, "i-Venture" },
                    { 2812, 174, false, "i-Wild" },
                    { 2813, 175, false, "SU7" },
                    { 2814, 176, false, "001" },
                    { 2815, 176, false, "007" },
                    { 2816, 176, false, "009" },
                    { 2817, 176, false, "7X" },
                    { 2818, 176, false, "X" },
                    { 2819, 177, false, "1111 Ока" },
                    { 2820, 177, false, "2101" },
                    { 2821, 177, false, "2102" },
                    { 2822, 177, false, "2103" },
                    { 2823, 177, false, "2104" },
                    { 2824, 177, false, "2105" },
                    { 2825, 177, false, "2106" },
                    { 2826, 177, false, "2107" },
                    { 2827, 177, false, "2108" },
                    { 2828, 177, false, "2109" },
                    { 2829, 177, false, "21099" },
                    { 2830, 177, false, "2110" },
                    { 2831, 177, false, "2111" },
                    { 2832, 177, false, "2112" },
                    { 2833, 177, false, "2113" },
                    { 2834, 177, false, "2114" },
                    { 2835, 177, false, "2115" },
                    { 2836, 177, false, "2120 Надежда" },
                    { 2837, 177, false, "2121 (4x4)" },
                    { 2838, 177, false, "Lada 2121" }
                });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[] { 2839, 177, false, "Lada 2131 (5-ти дверный)" });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[] { 2840, 177, false, "2123" });

            migrationBuilder.InsertData(
                table: "ModelCars",
                columns: new[] { "Id", "CarId", "IsDeleted", "Name" },
                values: new object[] { 2841, 177, false, "" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 697);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 698);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 699);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 700);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 701);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 702);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 703);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 704);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 705);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 706);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 707);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 708);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 709);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 710);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 711);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 712);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 713);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 714);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 715);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 716);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 717);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 718);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 719);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 720);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 721);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 722);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 723);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 724);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 725);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 726);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 727);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 728);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 729);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 730);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 731);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 732);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 733);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 734);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 735);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 736);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 737);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 738);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 739);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 740);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 741);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 742);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 743);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 744);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 745);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 746);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 747);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 748);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 749);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 750);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 751);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 752);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 753);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 754);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 755);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 756);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 757);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 758);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 759);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 760);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 761);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 762);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 763);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 764);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 765);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 766);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 767);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 768);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 769);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 770);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 771);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 772);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 773);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 774);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 775);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 776);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 777);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 778);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 779);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 780);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 781);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 782);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 783);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 784);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 785);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 786);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 787);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 788);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 789);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 790);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 791);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 792);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 793);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 794);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 795);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 796);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 797);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 798);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 799);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 800);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 801);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 802);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 803);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 804);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 805);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 806);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 807);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 808);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 809);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 810);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 811);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 812);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 813);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 814);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 815);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 816);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 817);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 818);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 819);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 820);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 821);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 822);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 823);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 824);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 825);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 826);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 827);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 828);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 829);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 830);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 831);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 832);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 833);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 834);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 835);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 836);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 837);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 838);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 839);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 840);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 841);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 842);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 843);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 844);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 845);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 846);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 847);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 848);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 849);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 850);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 851);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 852);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 853);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 854);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 855);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 856);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 857);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 858);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 859);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 860);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 861);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 862);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 863);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 864);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 865);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 866);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 867);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 868);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 869);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 870);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 871);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 872);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 873);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 874);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 875);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 876);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 877);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 878);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 879);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 880);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 881);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 882);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 883);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 884);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 885);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 886);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 887);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 888);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 889);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 890);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 891);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 892);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 893);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 894);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 895);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 896);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 897);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 898);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 899);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 900);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 901);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 902);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 903);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 904);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 905);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 906);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 907);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 908);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 909);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 910);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 911);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 912);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 913);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 914);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 915);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 916);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 917);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 918);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 919);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 920);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 921);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 922);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 923);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 924);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 925);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 926);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 927);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 928);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 929);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 930);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 931);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 932);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 933);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 934);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 935);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 936);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 937);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 938);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 939);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 940);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 941);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 942);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 943);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 944);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 945);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 946);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 947);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 948);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 949);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 950);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 951);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 952);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 953);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 954);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 955);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 956);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 957);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 958);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 959);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 960);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 961);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 962);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 963);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 964);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 965);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 966);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 967);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 968);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 969);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 970);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 971);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 972);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 973);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 974);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 975);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 976);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 977);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 978);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 979);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 980);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 981);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 982);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 983);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 984);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 985);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 986);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 987);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 988);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 989);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 990);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 991);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 992);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 993);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 994);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 995);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 996);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 997);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 998);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 999);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1000);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1001);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1002);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1003);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1004);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1005);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1006);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1007);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1008);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1009);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1010);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1011);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1012);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1013);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1014);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1015);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1016);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1017);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1018);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1019);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1020);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1021);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1022);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1023);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1024);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1025);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1026);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1027);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1028);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1029);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1030);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1031);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1032);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1033);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1034);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1035);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1036);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1037);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1038);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1039);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1040);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1041);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1042);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1043);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1044);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1045);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1046);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1047);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1048);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1049);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1050);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1051);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1052);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1053);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1054);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1055);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1056);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1057);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1058);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1059);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1060);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1061);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1062);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1063);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1064);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1065);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1066);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1067);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1068);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1069);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1070);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1071);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1072);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1073);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1074);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1075);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1076);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1077);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1078);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1079);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1080);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1081);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1082);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1083);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1084);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1085);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1086);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1087);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1088);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1089);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1090);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1091);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1092);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1093);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1094);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1095);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1096);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1097);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1098);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1099);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1100);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1101);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1102);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1103);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1104);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1105);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1106);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1107);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1108);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1109);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1110);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1111);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1112);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1113);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1114);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1115);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1116);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1117);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1118);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1119);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1120);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1121);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1122);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1123);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1124);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1125);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1126);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1127);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1128);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1129);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1130);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1131);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1132);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1133);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1134);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1135);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1136);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1137);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1138);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1139);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1140);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1141);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1142);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1143);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1144);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1145);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1146);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1147);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1148);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1149);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1150);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1151);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1152);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1153);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1154);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1155);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1156);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1157);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1158);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1159);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1160);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1161);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1162);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1163);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1164);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1165);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1166);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1167);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1168);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1169);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1170);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1171);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1172);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1173);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1174);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1175);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1176);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1177);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1178);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1179);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1180);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1181);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1182);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1183);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1184);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1185);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1186);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1187);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1188);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1189);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1190);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1191);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1192);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1193);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1194);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1195);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1196);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1197);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1198);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1199);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1200);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1201);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1202);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1203);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1204);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1205);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1206);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1207);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1208);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1209);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1210);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1211);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1212);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1213);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1214);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1215);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1216);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1217);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1218);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1219);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1220);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1221);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1222);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1223);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1224);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1225);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1226);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1227);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1228);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1229);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1230);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1231);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1232);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1233);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1234);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1235);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1236);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1237);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1238);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1239);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1240);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1241);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1242);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1243);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1244);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1245);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1246);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1247);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1248);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1249);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1250);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1251);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1252);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1253);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1254);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1255);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1256);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1257);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1258);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1259);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1260);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1261);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1262);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1263);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1264);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1265);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1266);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1267);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1268);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1269);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1270);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1271);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1272);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1273);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1274);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1275);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1276);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1277);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1278);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1279);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1280);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1281);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1282);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1283);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1284);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1285);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1286);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1287);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1288);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1289);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1290);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1291);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1292);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1293);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1294);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1295);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1296);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1297);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1298);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1299);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1300);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1301);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1302);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1303);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1304);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1305);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1306);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1307);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1308);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1309);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1310);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1311);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1312);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1313);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1314);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1315);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1316);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1317);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1318);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1319);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1320);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1321);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1322);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1323);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1324);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1325);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1326);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1327);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1328);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1329);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1330);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1331);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1332);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1333);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1334);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1335);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1336);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1337);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1338);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1339);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1340);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1341);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1342);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1343);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1344);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1345);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1346);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1347);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1348);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1349);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1350);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1351);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1352);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1353);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1354);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1355);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1356);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1357);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1358);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1359);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1360);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1361);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1362);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1363);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1364);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1365);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1366);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1367);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1368);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1369);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1370);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1371);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1372);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1373);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1374);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1375);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1376);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1377);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1378);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1379);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1380);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1381);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1382);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1383);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1384);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1385);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1386);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1387);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1388);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1389);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1390);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1391);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1392);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1393);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1394);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1395);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1396);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1397);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1398);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1399);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1400);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1401);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1402);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1403);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1404);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1405);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1406);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1407);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1408);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1409);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1410);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1411);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1412);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1413);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1414);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1415);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1416);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1417);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1418);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1419);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1420);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1421);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1422);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1423);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1424);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1425);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1426);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1427);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1428);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1429);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1430);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1431);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1432);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1433);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1434);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1435);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1436);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1437);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1438);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1439);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1440);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1441);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1442);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1443);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1444);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1445);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1446);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1447);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1448);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1449);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1450);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1451);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1452);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1453);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1454);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1455);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1456);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1457);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1458);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1459);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1460);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1461);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1462);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1463);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1464);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1465);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1466);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1467);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1468);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1469);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1470);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1471);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1472);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1473);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1474);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1475);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1476);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1477);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1478);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1479);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1480);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1481);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1482);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1483);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1484);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1485);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1486);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1487);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1488);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1489);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1490);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1491);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1492);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1493);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1494);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1495);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1496);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1497);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1498);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1499);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1500);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1501);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1502);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1503);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1504);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1505);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1506);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1507);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1508);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1509);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1510);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1511);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1512);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1513);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1514);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1515);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1516);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1517);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1518);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1519);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1520);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1521);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1522);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1523);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1524);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1525);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1526);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1527);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1528);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1529);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1530);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1531);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1532);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1533);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1534);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1535);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1536);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1537);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1538);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1539);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1540);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1541);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1542);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1543);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1544);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1545);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1546);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1547);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1548);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1549);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1550);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1551);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1552);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1553);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1554);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1555);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1556);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1557);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1558);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1559);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1560);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1561);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1562);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1563);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1564);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1565);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1566);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1567);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1568);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1569);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1570);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1571);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1572);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1573);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1574);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1575);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1576);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1577);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1578);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1579);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1580);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1581);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1582);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1583);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1584);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1585);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1586);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1587);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1588);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1589);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1590);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1591);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1592);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1593);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1594);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1595);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1596);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1597);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1598);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1599);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1600);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1601);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1602);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1603);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1604);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1605);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1606);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1607);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1608);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1609);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1610);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1611);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1612);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1613);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1614);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1615);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1616);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1617);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1618);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1619);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1620);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1621);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1622);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1623);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1624);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1625);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1626);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1627);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1628);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1629);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1630);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1631);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1632);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1633);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1634);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1635);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1636);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1637);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1638);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1639);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1640);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1641);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1642);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1643);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1644);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1645);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1646);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1647);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1648);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1649);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1650);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1651);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1652);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1653);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1654);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1655);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1656);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1657);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1658);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1659);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1660);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1661);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1662);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1663);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1664);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1665);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1666);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1667);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1668);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1669);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1670);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1671);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1672);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1673);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1674);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1675);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1676);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1677);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1678);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1679);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1680);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1681);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1682);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1683);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1684);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1685);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1686);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1687);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1688);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1689);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1690);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1691);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1692);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1693);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1694);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1695);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1696);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1697);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1698);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1699);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1700);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1701);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1702);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1703);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1704);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1705);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1706);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1707);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1708);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1709);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1710);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1711);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1712);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1713);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1714);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1715);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1716);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1717);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1718);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1719);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1720);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1721);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1722);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1723);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1724);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1725);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1726);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1727);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1728);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1729);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1730);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1731);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1732);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1733);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1734);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1735);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1736);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1737);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1738);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1739);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1740);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1741);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1742);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1743);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1744);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1745);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1746);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1747);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1748);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1749);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1750);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1751);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1752);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1753);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1754);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1755);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1756);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1757);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1758);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1759);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1760);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1761);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1762);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1763);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1764);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1765);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1766);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1767);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1768);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1769);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1770);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1771);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1772);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1773);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1774);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1775);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1776);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1777);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1778);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1779);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1780);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1781);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1782);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1783);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1784);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1785);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1786);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1787);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1788);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1789);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1790);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1791);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1792);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1793);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1794);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1795);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1796);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1797);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1798);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1799);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1800);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1801);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1802);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1803);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1804);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1805);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1806);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1807);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1808);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1809);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1810);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1811);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1812);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1813);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1814);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1815);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1816);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1817);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1818);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1819);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1820);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1821);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1822);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1823);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1824);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1825);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1826);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1827);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1828);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1829);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1830);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1831);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1832);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1833);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1834);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1835);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1836);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1837);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1838);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1839);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1840);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1841);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1842);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1843);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1844);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1845);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1846);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1847);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1848);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1849);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1850);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1851);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1852);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1853);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1854);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1855);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1856);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1857);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1858);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1859);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1860);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1861);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1862);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1863);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1864);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1865);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1866);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1867);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1868);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1869);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1870);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1871);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1872);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1873);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1874);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1875);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1876);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1877);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1878);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1879);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1880);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1881);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1882);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1883);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1884);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1885);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1886);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1887);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1888);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1889);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1890);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1891);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1892);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1893);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1894);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1895);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1896);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1897);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1898);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1899);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1900);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1901);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1902);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1903);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1904);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1905);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1906);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1907);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1908);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1909);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1910);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1911);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1912);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1913);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1914);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1915);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1916);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1917);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1918);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1919);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1920);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1921);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1922);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1923);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1924);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1925);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1926);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1927);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1928);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1929);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1930);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1931);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1932);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1933);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1934);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1935);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1936);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1937);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1938);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1939);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1940);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1941);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1942);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1943);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1944);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1945);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1946);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1947);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1948);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1949);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1950);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1951);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1952);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1953);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1954);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1955);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1956);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1957);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1958);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1959);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1960);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1961);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1962);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1963);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1964);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1965);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1966);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1967);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1968);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1969);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1970);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1971);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1972);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1973);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1974);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1975);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1976);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1977);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1978);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1979);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1980);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1981);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1982);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1983);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1984);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1985);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1986);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1987);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1988);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1989);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1990);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1991);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1992);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1993);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1994);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1995);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1996);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1997);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1998);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 1999);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2000);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2001);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2002);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2003);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2004);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2005);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2006);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2007);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2008);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2009);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2010);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2011);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2012);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2013);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2014);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2015);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2016);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2017);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2018);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2019);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2020);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2021);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2022);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2023);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2024);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2025);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2026);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2027);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2028);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2029);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2030);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2031);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2032);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2033);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2034);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2035);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2036);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2037);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2038);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2039);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2040);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2041);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2042);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2043);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2044);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2045);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2046);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2047);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2048);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2049);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2050);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2051);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2052);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2053);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2054);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2055);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2056);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2057);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2058);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2059);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2060);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2061);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2062);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2063);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2064);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2065);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2066);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2067);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2068);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2069);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2070);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2071);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2072);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2073);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2074);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2075);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2076);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2077);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2078);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2079);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2080);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2081);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2082);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2083);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2084);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2085);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2086);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2087);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2088);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2089);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2090);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2091);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2092);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2093);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2094);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2095);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2096);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2097);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2098);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2099);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2100);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2101);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2102);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2103);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2104);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2105);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2106);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2107);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2108);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2109);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2110);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2111);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2112);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2113);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2114);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2115);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2116);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2117);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2118);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2119);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2120);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2121);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2122);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2123);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2124);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2125);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2126);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2127);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2128);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2129);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2130);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2131);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2132);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2133);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2134);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2135);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2136);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2137);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2138);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2139);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2140);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2141);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2142);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2143);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2144);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2145);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2146);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2147);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2148);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2149);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2150);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2151);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2152);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2153);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2154);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2155);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2156);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2157);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2158);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2159);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2160);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2161);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2162);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2163);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2164);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2165);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2166);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2167);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2168);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2169);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2170);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2171);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2172);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2173);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2174);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2175);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2176);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2177);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2178);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2179);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2180);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2181);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2182);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2183);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2184);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2185);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2186);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2187);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2188);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2189);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2190);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2191);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2192);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2193);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2194);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2195);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2196);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2197);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2198);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2199);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2200);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2201);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2202);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2203);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2204);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2205);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2206);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2207);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2208);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2209);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2210);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2211);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2212);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2213);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2214);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2215);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2216);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2217);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2218);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2219);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2220);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2221);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2222);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2223);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2224);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2225);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2226);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2227);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2228);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2229);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2230);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2231);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2232);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2233);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2234);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2235);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2236);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2237);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2238);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2239);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2240);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2241);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2242);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2243);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2244);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2245);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2246);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2247);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2248);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2249);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2250);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2251);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2252);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2253);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2254);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2255);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2256);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2257);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2258);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2259);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2260);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2261);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2262);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2263);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2264);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2265);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2266);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2267);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2268);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2269);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2270);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2271);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2272);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2273);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2274);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2275);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2276);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2277);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2278);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2279);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2280);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2281);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2282);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2283);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2284);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2285);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2286);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2287);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2288);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2289);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2290);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2291);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2292);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2293);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2294);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2295);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2296);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2297);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2298);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2299);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2300);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2301);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2302);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2303);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2304);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2305);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2306);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2307);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2308);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2309);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2310);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2311);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2312);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2313);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2314);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2315);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2316);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2317);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2318);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2319);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2320);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2321);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2322);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2323);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2324);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2325);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2326);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2327);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2328);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2329);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2330);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2331);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2332);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2333);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2334);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2335);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2336);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2337);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2338);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2339);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2340);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2341);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2342);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2343);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2344);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2345);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2346);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2347);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2348);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2349);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2350);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2351);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2352);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2353);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2354);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2355);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2356);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2357);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2358);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2359);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2360);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2361);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2362);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2363);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2364);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2365);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2366);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2367);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2368);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2369);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2370);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2371);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2372);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2373);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2374);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2375);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2376);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2377);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2378);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2379);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2380);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2381);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2382);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2383);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2384);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2385);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2386);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2387);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2388);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2389);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2390);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2391);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2392);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2393);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2394);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2395);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2396);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2397);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2398);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2399);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2400);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2401);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2402);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2403);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2404);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2405);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2406);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2407);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2408);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2409);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2410);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2411);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2412);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2413);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2414);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2415);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2416);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2417);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2418);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2419);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2420);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2421);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2422);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2423);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2424);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2425);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2426);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2427);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2428);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2429);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2430);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2431);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2432);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2433);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2434);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2435);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2436);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2437);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2438);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2439);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2440);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2441);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2442);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2443);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2444);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2445);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2446);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2447);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2448);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2449);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2450);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2451);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2452);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2453);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2454);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2455);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2456);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2457);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2458);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2459);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2460);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2461);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2462);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2463);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2464);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2465);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2466);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2467);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2468);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2469);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2470);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2471);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2472);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2473);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2474);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2475);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2476);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2477);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2478);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2479);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2480);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2481);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2482);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2483);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2484);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2485);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2486);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2487);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2488);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2489);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2490);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2491);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2492);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2493);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2494);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2495);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2496);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2497);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2498);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2499);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2500);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2501);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2502);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2503);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2504);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2505);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2506);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2507);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2508);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2509);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2510);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2511);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2512);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2513);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2514);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2515);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2516);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2517);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2518);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2519);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2520);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2521);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2522);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2523);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2524);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2525);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2526);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2527);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2528);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2529);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2530);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2531);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2532);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2533);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2534);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2535);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2536);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2537);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2538);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2539);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2540);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2541);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2542);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2543);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2544);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2545);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2546);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2547);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2548);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2549);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2550);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2551);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2552);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2553);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2554);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2555);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2556);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2557);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2558);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2559);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2560);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2561);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2562);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2563);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2564);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2565);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2566);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2567);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2568);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2569);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2570);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2571);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2572);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2573);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2574);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2575);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2576);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2577);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2578);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2579);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2580);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2581);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2582);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2583);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2584);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2585);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2586);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2587);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2588);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2589);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2590);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2591);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2592);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2593);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2594);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2595);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2596);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2597);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2598);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2599);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2600);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2601);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2602);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2603);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2604);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2605);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2606);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2607);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2608);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2609);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2610);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2611);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2612);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2613);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2614);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2615);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2616);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2617);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2618);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2619);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2620);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2621);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2622);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2623);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2624);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2625);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2626);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2627);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2628);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2629);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2630);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2631);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2632);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2633);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2634);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2635);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2636);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2637);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2638);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2639);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2640);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2641);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2642);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2643);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2644);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2645);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2646);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2647);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2648);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2649);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2650);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2651);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2652);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2653);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2654);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2655);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2656);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2657);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2658);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2659);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2660);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2661);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2662);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2663);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2664);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2665);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2666);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2667);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2668);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2669);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2670);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2671);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2672);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2673);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2674);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2675);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2676);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2677);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2678);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2679);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2680);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2681);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2682);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2683);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2684);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2685);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2686);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2687);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2688);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2689);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2690);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2691);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2692);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2693);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2694);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2695);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2696);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2697);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2698);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2699);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2700);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2701);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2702);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2703);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2704);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2705);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2706);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2707);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2708);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2709);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2710);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2711);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2712);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2713);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2714);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2715);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2716);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2717);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2718);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2719);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2720);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2721);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2722);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2723);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2724);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2725);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2726);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2727);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2728);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2729);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2730);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2731);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2732);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2733);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2734);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2735);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2736);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2737);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2738);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2739);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2740);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2741);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2742);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2743);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2744);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2745);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2746);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2747);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2748);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2749);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2750);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2751);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2752);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2753);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2754);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2755);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2756);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2757);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2758);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2759);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2760);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2761);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2762);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2763);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2764);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2765);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2766);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2767);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2768);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2769);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2770);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2771);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2772);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2773);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2774);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2775);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2776);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2777);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2778);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2779);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2780);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2781);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2782);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2783);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2784);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2785);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2786);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2787);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2788);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2789);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2790);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2791);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2792);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2793);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2794);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2795);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2796);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2797);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2798);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2799);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2800);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2801);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2802);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2803);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2804);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2805);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2806);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2807);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2808);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2809);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2810);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2811);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2812);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2813);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2814);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2815);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2816);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2817);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2818);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2819);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2820);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2821);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2822);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2823);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2824);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2825);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2826);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2827);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2828);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2829);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2830);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2831);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2832);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2833);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2834);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2835);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2836);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2837);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2838);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2839);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2840);

            migrationBuilder.DeleteData(
                table: "ModelCars",
                keyColumn: "Id",
                keyValue: 2841);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 43);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 44);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 45);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 48);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 49);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 50);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 51);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 52);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 53);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 54);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 55);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 56);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 57);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 58);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 59);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 60);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 61);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 62);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 63);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 64);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 65);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 66);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 67);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 68);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 69);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 70);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 71);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 72);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 73);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 74);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 75);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 76);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 77);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 78);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 79);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 80);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 81);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 82);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 83);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 84);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 85);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 86);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 87);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 88);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 89);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 90);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 91);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 92);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 93);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 94);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 95);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 96);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 97);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 98);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 99);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 100);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 101);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 102);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 103);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 104);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 105);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 106);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 107);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 108);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 109);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 110);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 111);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 112);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 113);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 114);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 115);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 116);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 117);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 118);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 119);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 120);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 121);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 122);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 123);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 124);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 125);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 126);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 127);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 128);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 129);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 130);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 131);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 132);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 133);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 134);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 135);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 136);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 137);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 138);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 139);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 140);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 141);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 142);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 143);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 144);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 145);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 146);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 147);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 148);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 149);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 150);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 151);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 152);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 153);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 154);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 155);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 156);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 157);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 158);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 159);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 160);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 161);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 162);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 163);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 164);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 165);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 166);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 167);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 168);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 169);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 170);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 171);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 172);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 173);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 174);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 175);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 176);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Id",
                keyValue: 177);

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "5ca727a1-be5c-48bf-84b9-3a7c8e9b02ca", "52f92fcd-1e1f-4f15-916f-707ab0c26f94", "Менеджер", "МЕНЕДЖЕР" },
                    { "7fde158f-22b2-4831-8f5e-05d8a9f4c5c8", "2fadea65-5249-4695-8c0d-c18df2e80300", "Мастер", "МАСТЕР" },
                    { "bf1bde28-1261-44dc-b067-e3d521c8f4aa", "ce454d31-7462-4416-b1c2-fa3f90c4a1f2", "Директор", "Директор" }
                });

            migrationBuilder.InsertData(
                table: "PaymentMethods",
                columns: new[] { "Id", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1, false, "Наличный" },
                    { 2, false, "Безналичный" },
                    { 3, false, "Смешанная оплата" }
                });

            migrationBuilder.InsertData(
                table: "TypeOfOrganizations",
                columns: new[] { "Id", "IsDeleted", "Name" },
                values: new object[,]
                {
                    { 1, false, "Detailing" },
                    { 2, false, "Car wash" }
                });
        }
    }
}
