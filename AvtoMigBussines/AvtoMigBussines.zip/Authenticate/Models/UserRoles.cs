﻿namespace AvtoMigBussines.Authenticate.Models
{
    public class UserRoles
    {
        public string RoleName { get; set; }
    }
}
