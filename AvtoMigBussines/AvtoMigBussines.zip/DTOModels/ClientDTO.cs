﻿namespace AvtoMigBussines.DTOModels
{
    public class ClientDTO
    {
        public string? ClientPhoneNumber { get; set; }
    }
}
