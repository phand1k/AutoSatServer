﻿namespace AvtoMigBussines.DTOModels
{
    public class MostPopularCarsDTO
    {
        public string? CarName { get; set; }
        public int? Count { get; set; }
        public double? UsagePercent { get; set; }
    }
}
