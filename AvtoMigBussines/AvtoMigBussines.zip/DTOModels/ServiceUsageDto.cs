﻿namespace AvtoMigBussines.DTOModels
{
    public class ServiceUsageDto
    {
        public string? Name { get; set; }
        public double? Price { get; set; }
        public double UsagePercent { get; set; }
        public int? Count { get; set; }
    }
}
