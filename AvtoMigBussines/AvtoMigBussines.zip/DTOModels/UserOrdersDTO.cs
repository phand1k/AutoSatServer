﻿namespace AvtoMigBussines.DTOModels
{
    public class UserOrdersDTO
    {
        public string? ServiceName { get; set; }
        public string? FullNameUser { get; set; }

    }
}
